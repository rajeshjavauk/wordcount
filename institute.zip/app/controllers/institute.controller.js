const client = require('../config/db.config.js')

const getPagination = (page, size) => {
  const limit = size ? +size : 3;
  const offset = page ? page * limit : 0;

  return { limit, offset };
};

const getPagingData = (result, count, page, limit) => {
  const data = result.rows;
  const totalItems = count;
  const currentPage = page ? +page : 0;
  const totalPages = Math.ceil(totalItems / limit);

  return { totalItems, data, totalPages, currentPage };
};

// Retrieve all Tutorials from the database.
exports.findAll = (req, res) => {
  const { page, size, state } = req.query;
  //var condition = state ? { state: { [Op.eq]: `${state}` } } : null;
  const { limit, offset } = getPagination(page, size);
  //const { count } = client.query("Select count(1) from instituteslist");
  const count=0;
  try{
    client.query("Select * from instituteslist limit " + limit + " offset "+ offset , (err, result)=>{
      if(!err){
        //res.send(result.rows);
        const response = getPagingData(result, count, page, limit);
        res.send(response);
      }else{
        console.log(err.message);
        res.status(500).send({
          message:
            err.message || "Some error occurred while retrieving tutorials."
        });
      }
     });
    }catch(e){
      console.log(r.message);
    }
    finally{
      client.end;
    }
  res.status(200).send([]);
};