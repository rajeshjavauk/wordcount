const getjobListParams = {
  type: 'object',
  additionalProperties: false,
  properties: {
    corporateId: { type: 'string', format: 'uuid' },
  },
  required: ['corporateId'],
};
const getjobListquery = {
  type: 'object',
  additionalProperties: false,
  properties: {
    jobType: { enum: ['FULL', 'PART', 'HYBRID'], },
    jobTypeLevel: { enum: ['ENTRY', 'INTERN'] },
    postedOnStart: { type: 'string', format: 'date' },
    postedOnEnd: { type: 'string', format: 'date' },
    status: { type: 'number', maximum: 1, minimum: -1 },
    pageLimit: { type: 'number', default: 10, minimum: 1 },
    pageNo: { type: 'number', default: 0 },
    sort: { enum: ['tittle', 'postedDate', 'status', 'candidates', 'colleges'] }, ///'institute', 'candidates' sorting par remaing 
    orderBy: { enum: ['desc', 'asc'] },
    searchBy: { type: 'string' }
  },
  required: [],
}

exports.getJobByCorpIdSchema = {
  description: 'This is an endpoint for get corporate job roles list',
  tags: ['corporate'],
  params: getjobListParams,
  querystring: getjobListquery
};