
const params = {
    type: 'object',
    additionalProperties: false,
    properties: {
      corporateId: { type: 'string', format: 'uuid' },
    },
    required: ['corporateId'],
  };

  const searchParams = {
    type: 'object',
    additionalProperties: false,
    properties: {
        state: {
            type: 'string'
        },
        city: {
            type: 'string'
        },
        createdAtStart: { 
          type: 'string', 
          format: 'date' 
        },
        createdAtEnd: { 
          type: 'string', 
          format: 'date' 
        },
        size: {
            type: 'integer',
            default: 10, maximum: 25, minimum: 1
        },
        page: {
            type: 'integer',
            default: 0
        },
  
    },
  };
  
  exports.getCorporateByIdSchema = {
    description: 'This is an endpoint for get corporate details',
    tags: ['corporate'],
    params: params,
  };

  exports.getCorporateSchema = {
    description: 'This is an endpoint for search corporate',
    tags: ['corporate'],
    querystring: searchParams,
  };