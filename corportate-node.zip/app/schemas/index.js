const corporate = require('./corporate');
const jobRole = require('./jobRoles');

module.exports = {
  corporate,
  jobRole
};
