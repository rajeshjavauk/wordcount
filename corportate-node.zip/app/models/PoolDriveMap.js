const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class PoolDriveMap {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

}

module.exports = PoolDriveMap;
