const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class JobDrive {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

  async getById(id) {
    const jobDrive = await prisma.drive.findFirst({
      where: {
        id,
      },
      include: {
        poolDriveInstituteCampusMap: true
      }
    });
    return jobDrive;
  }

  async scheduleDrive() {
    const { driveId, hostCollegeId, driveStartDate, driveEndDate, driveStartTime, driveEndTime } = this.data
    let updateObj = {
      where: { id: driveId, hostCollegeId },
      data: {
        startDate: new Date(driveStartDate), endDate: new Date(driveEndDate),
        startTime: driveStartTime, endTime: driveEndTime,
        instituteStatus: "REQUESTED", corporateStatus: "PENDING", corporateReason: null, instituteReason: null
      }
    }
    const jobDrive = await prisma.drive.updateMany(updateObj);
    this.data = jobDrive;
    return jobDrive;
  }

  async getDriveList() {
    const jobDrive = await prisma.drive.findMany(this.data);
    this.data = jobDrive;
    return jobDrive;
  }

  async getListCount() {
    const count = await prisma.drive.count({ where: this.data.where });
    return count;
  }

  async driveCount(where) {
    const count = await prisma.drive.count({ where });
    return count;
  }

  async aggregate(whereClouse) {
    const counts = await prisma.drive.aggregate({ where: whereClouse, _count: true });
    return counts
  }

  async getDriveDetails() {
    const details = await prisma.drive.findFirst(this.data);
    this.data = details;
  }

  async driveRoleCount(where) {
    const count = await prisma.driveRoleMap.count({ where });
    return count;
  }

  async getCount(where) {
    const count = await prisma.driveRoleCandidateMap.count({ where });
    return count;
  }

  async interviewerList() {
    const details = await prisma.driveInterviewerMap.findMany({ where: { driveId: this.data, deletedAt: null } });
    this.data = details;
  }

  async requestToChange(note) {
    const details = await prisma.drive.update({ where: { id: this.data }, data: { corporateStatus: "REQUESTED", corporateReason: note, instituteStatus: "PENDING" } });
    this.data = details;
    return details
  }

  async rescheduleDrive() {
    const details = await prisma.drive.updateMany(this.data);
    this.data = details;
  }

  async driveDetail(where) {
    const details = await prisma.drive.findFirst({ where });
    return details;
  }

  async confirmDriveDate() {
    const details = await prisma.drive.update({ where: this.data.where, data: { instituteStatus: "CONFIRMED", corporateStatus: "CONFIRMED" } });
    this.data = details;
    return details
  }

  async instituteDriveInfo(where, include) {
    const details = await prisma.drive.findMany({ where, include });
    this.data = details;
    return details
  }

  async getDriveRoles(where, include) {
    const details = await prisma.driveRoleMap.findMany({ where, include });
    return details;
  }

}

module.exports = JobDrive;
