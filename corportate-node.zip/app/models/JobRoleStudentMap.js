const _ = require('lodash');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class JobRoleStudentMap {

  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

  async getMany() {
    const jobRoleStudentMap = await prisma.jobRoleStudentMap.findMany(
      this.data,
    );
    this.data = jobRoleStudentMap;
  }

  async roleDocCount() {
    const jobRoleStudentMap = await prisma.jobRoleStudentMap.count({
      where: this.data.where,
    });
    return jobRoleStudentMap;
  }

  async getMetricsCount(data) {
    const result = {
      applied: await prisma.jobRoleStudentMap.count({ where: data }) || 0,
      "active/shortlisted": await prisma.jobRoleStudentMap.count({ where: { ...data, status: { in: ["ACTIVE", "SHORTLISTED"] } } }) || 0,
      rejected: await prisma.jobRoleStudentMap.count({ where: { ...data, status: "REJECTED" } }) || 0,
      offerReceived: await prisma.jobRoleStudentMap.count({ where: { ...data, status: "OFFER_RECEIVED" } }) || 0
    }
    this.data = result;
  }

  async getRoleMap() {
    const jobRoleStudentMap = await prisma.jobRoleStudentMap.findFirst(this.data)
    this.data = jobRoleStudentMap;
    return jobRoleStudentMap
  }

}

module.exports = JobRoleStudentMap;