const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class Functions {
    constructor(input, request) {
        this.data = input;
        this.request = request;
    }

    async getFunctionList() {
        const functionData = await prisma.functions.findMany(this.data);
        this.data = functionData
    }

    async getFunctionsCount() {
        const count = await prisma.functions.count({ where: this.data.where });
        return count
    }

    async getDesignationList() {
        const functionData = await prisma.designations.findMany(this.data);
        this.data = functionData
    }

    async getDesignationCount() {
        const count = await prisma.designations.count({ where: this.data.where });
        return count
    }
}

module.exports = Functions;
