const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class StudentInterviewMap {
    constructor(input, request) {
        this.data = input;
        this.request = request;
    }

    async findFirst(data) {
        const studentInterviewMap = await prisma.studentInterviewMap.findFirst({where:data});
        this.data = studentInterviewMap;
        return studentInterviewMap;
    }

    async findMany(data) {
        const studentInterviewMap = await prisma.studentInterviewMap.findMany({where:data});
        this.data = studentInterviewMap;
        return studentInterviewMap;
    }
}

module.exports = StudentInterviewMap;
