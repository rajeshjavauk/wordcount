const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class DriveRoleMap {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

  async getDriveByRoleAndHostCollegeId() {
    const { roleId, hostCollegeId } = this.data;
    const driveRoleMap = await prisma.driveRoleMap.findMany({
      where: {
        roleId: roleId,
        drive: {
          hostCollegeId: hostCollegeId,
        },
      },
      include: { drive: true }
    });
    this.data = driveRoleMap;
    return this.data;
  }

  async getRoleDriveMap() {
    const driveRoleMap = await prisma.driveRoleMap.findFirst({
      where: this.data
    });
    return driveRoleMap ? true : false
  }

  async getByRole(data){
    const driveRoleMap = await prisma.driveRoleMap.findMany({
      where: data
    });
    this.data = driveRoleMap;
    return driveRoleMap
  }

}

module.exports = DriveRoleMap;
