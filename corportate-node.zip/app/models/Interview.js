const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class Interview {
    constructor(input, request) {
        this.data = input;
        this.request = request;
    }

    async getById(id) {
        const interviewData = await prisma.interview.findFirst({
            where: {
                id,
            },
        });
        this.data = interviewData;
        return interviewData;
    }


    async findFirst(whereClause) {
        const interviews = await prisma.interview.findFirst({
            where:whereClause
        });
        this.data = interviews
        return interviews
    } 


}

module.exports = Interview;
