const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class DriveInterviewerMap {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }
  /*
  async create() {
    const { driveId, interviewerId } = this.data;
    const where = { driveId_interviewerId: { driveId, interviewerId } }
    const upsertObj = { driveId, interviewerId }
    const driveInterviewerMapData = await prisma.driveInterviewerMap.upsert({ where, update: { driveId, interviewerId, deletedAt: null }, create: upsertObj });
    this.data = driveInterviewerMapData;
    return driveInterviewerMapData;
  }
*/

  async findMany(data) {
    const driveInterviewerMapData = await prisma.driveInterviewerMap.findMany({
      where: data
    });
    this.data = driveInterviewerMapData;
    return driveInterviewerMapData;
  }

}

module.exports = DriveInterviewerMap;