const { PrismaClient } = require('@prisma/client');
const _ = require('lodash');

const prisma = new PrismaClient();

class Corporate {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

  async getById(id) {
    const corporateData = await prisma.corporate.findUnique({
      where: {
        id,
      },
    });
    this.data = corporateData;
    return corporateData;
  };


  async list({ state, city, createdAtStart, createdAtEnd, sort, orderBy = 'desc', page, size, }) {
    const whereClouse = {
      AND: [{
        deletedAt: null
      }]
    }
    if (state) {
      whereClouse['AND'].push({ state: { startsWith: state, mode: 'insensitive' } });
    }
    if (city) {
      const cityList = city.split(',');
      whereClouse['AND'].push({
        city: {
          in: cityList.map(s => s)
        }
      });
    }
    const CreatedAt = []
    if (createdAtStart) {
      CreatedAt.push({
        createdAt: { gte: new Date(createdAtStart) }
      })
    }
    if (createdAtEnd) {
      CreatedAt.push({
        createdAt: { lte: new Date(createdAtEnd) }
      })
    }
    if (!_.isEmpty(CreatedAt)) {
      whereClouse['AND'] = CreatedAt

    }
    let count = await prisma.corporate.aggregate({
      where: whereClouse,
      _count: true
    });
    count = _.get(count, '_count', 0);
    if (count) {
      let orderByData = [
        {
          createdAt: orderBy
        }
      ]
      if (sort) {
        const sortQuery = [];
        sortQuery.push({
          [sort]: orderBy
        })
        orderByData = sortQuery
      }
      const query = {
        where: whereClouse,
        skip: page * size,
        take: size,
        orderBy: orderByData
      }
      const result = await prisma.corporate.findMany(query);
      return { result, count, page: page, limit: size, totalPage: Math.ceil(count / size) }
    } else {
      return { result: [], count, totalPage: 0 }
    }

  };


  //async getByRegion(state) {
  async getByRegion({ search, pageLimit, pageNo }) {
    console.log("99999999999999999" + search);
    const whereClouse = {
      AND: [
        {
          deletedAt: null
        }
      ]
    };
    if (search) {
      whereClouse['AND'].push({ state: { equals: search, } })
    }


    let counts = await prisma.corporate.aggregate({ where: whereClouse, _count: true });
    const count = _.get(counts, '_count', 0);
    if (count) {
      const query = {
        where: whereClouse,
        select: {
          id: true,
          name: true,
          state: true,
          contactNumber: true,
          salesperson: true,
        },
        skip: pageNo * pageLimit,
        take: pageLimit,
      }
      const result = await prisma.corporate.findMany(query);
      return { result, count, page: pageNo, limit: pageLimit, totalPage: Math.ceil(count / pageLimit) }
    } else {
      return { result: [], count, totalPage: 0 }
    }
  }

}


module.exports = Corporate;
