const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class DriveRoleCandidateMap {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

  async getDriveList() {
    const jobDrive = await prisma.driveRoleCandidateMap.findMany(this.data);
    this.data = jobDrive;
    return jobDrive;
  }

  async getListCount() {
    const count = await prisma.driveRoleCandidateMap.count({ where: this.data.where });
    return count;
  }

  async getCount(where) {
    const count = await prisma.driveRoleCandidateMap.count({ where });
    return count;
  }

}

module.exports = DriveRoleCandidateMap;
