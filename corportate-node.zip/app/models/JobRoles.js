const { PrismaClient } = require('@prisma/client');
const { jobRoles } = require('../helpers');
const _ = require('lodash');


const prisma = new PrismaClient();

class JobRole {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }
/*
  async create() {
    const jobRole = await prisma.jobRoles.create({
      data: this.data,
    });
    this.data = jobRole;
    return jobRole
  }
*/
  async getById(id) {
    const jobRoleData = await prisma.jobRoles.findFirst({
      where: {
        id,
      },
    });
    this.data = jobRoleData;
    return jobRoleData;
  }

  async findById(id) {
    const jobRoleData = await prisma.jobRoles.findFirst({
      where: {
        id,
      },
      include: {
        roleRankConfig: true,
        corporate: true
      }
    });
    this.data = jobRoleData;
    return jobRoleData;
  }
/*
  async update(data, id) {
    if (!_.isEmpty(data)) {
      if (_.isEmpty(id)) {
        id = this.data.id
      }

      const jobRoleData = await prisma.jobRoles.update({
        where: {
          id,
        },
        data,
      });

      this.data = jobRoleData;
      return jobRoleData
    }

  }
*/
  async getByIdAndCorporateId(id, corporateId) {
    const jobRoleData = await prisma.jobRoles.findFirst({
      where: {
        id,
        corporateId,
      },
      include: {
        corporate: {
          select: {
            id: true,
            name: true,
            logo: true,
            industry: true
          },
        },
        roleRankConfig: true
      }
    });
    this.data = jobRoleData;
    return jobRoleData;
  }

  // eslint-disable-next-line class-methods-use-this
  async getDashboardMetric(corporateId) {
    const response = await prisma.$queryRaw`SELECT * FROM job_role_metric WHERE corporate_id = ${corporateId}`;
    const data = JSON.stringify(response[0], (key, value) => (typeof value === 'bigint' ? value.toString() : value));
    return JSON.parse(data);
  }


  async list({ corporateId, jobTypeLevel, jobType, status, postedOnStart, postedOnEnd, sort, orderBy = 'desc', searchBy, pageNo, pageLimit, }) {
    const whereClouse = {
      AND: [{
        corporateId: corporateId,
        deletedAt: null
      }]
    }
    if (jobTypeLevel) {
      whereClouse['AND'].push({ jobTypeLevel: jobTypeLevel });
    }
    if (jobType) {
      whereClouse['AND'].push({ jobType: jobType });
    }
    if (status) {
      whereClouse['AND'].push({ status: status })
    }
    if (searchBy) {
      whereClouse['AND'].push({ tittle: { startsWith: searchBy, mode: 'insensitive', } })
    }
    const PostedOn = []
    if (postedOnStart) {
      PostedOn.push({
        postedDate: { gte: new Date(postedOnStart) }
      })
    }
    if (postedOnEnd) {
      PostedOn.push({
        postedDate: { lte: new Date(postedOnEnd) }
      })
    }
    if (!_.isEmpty(PostedOn)) {
      whereClouse['AND'] = PostedOn

    }
    let count = await prisma.jobRoles.aggregate({
      where: whereClouse,
      _count: true
    });
    count = _.get(count, '_count', 0);
    if (count) {
      let orderByData = [
        {
          createdAt: orderBy
        }
      ]
      if (sort) {
        const sortQuery = [];
        if (sort == 'candidates' || 'colleges') {
          sort = sort == 'candidates' ? 'jobRoleStudentMap' : 'jobRoleInstituteMap'
          sortQuery.push({
            [sort]: {
              _count: orderBy,
            }
          })
        } else {
          sortQuery.push({
            [sort]: orderBy
          })
        }
        orderByData = sortQuery
      }
      const query = {
        where: whereClouse,
        skip: pageNo * pageLimit,
        take: pageLimit,
        orderBy: orderByData,
        select: {
          id: true,
          tittle: true,
          jobTypeLevel: true,
          jobType: true,
          status: true,
          postedDate: true,
          duplicatedJobId: true,
          _count: {
            select: {
              jobRoleStudentMap: { where: { isApplied: 1 } },
              jobRoleInstituteMap: { where: { status: 1 } },
              driveRoleMap: true
            },
          },
        }
      }

      const result = await prisma.jobRoles.findMany(query);
      return { result, count, page: pageNo, limit: pageLimit, totalPage: Math.ceil(count / pageLimit) }
    } else {
      return { result: [], count, totalPage: 0 }
    }

  };

  async count(corporateId, condition) {
    const whereClouse = {
      corporateId: corporateId,
      deletedAt: null,
      ...condition
    }
    let count = await prisma.jobRoles.count({
      where: whereClouse,
    });
    return count
  };

  async getByIdAndInstituteCampusId(id, instituteCampusId) {
    const jobRoleData = await prisma.jobRoles.findUnique({
      where: {
        id
      },
      include: {
        jobRoleInstituteMap: {
          where: {
            instituteCampusId: instituteCampusId,
            jobId: id
          },
          select: {
            saved: true,
            status: true,
            rejectedReason: true,
            otherReason: true
          }
        },
        corporate: {
          select: {
            id: true,
            name: true,
            logo: true
          }
        }
      }
    });
    this.data = jobRoleData;
    return jobRoleData;
  }

/*
  async updateInstituteMapingUsingJobRole(id, instituteCampusId, data) {
    const jobRoleData = await prisma.jobRoles.update({
      where: {
        id
      },
      data: {
        jobRoleInstituteMap: {
          updateMany: {
            where: {
              instituteCampusId: instituteCampusId
            },
            data: data

          },
        }
      }
    })
    this.data = jobRoleData;
    return jobRoleData;
  }

*/
  async jobRoleListForStudent({ studentId, instituteCampusId, degreeStreamMapId, tenthScore, twelfthScore, UGScore, PGScore, arrear, endBatch, minCTC, maxCTC, jobTypeLevel, jobType, cities, saved, searchBy, sort = 'postedDate', order = 'desc', pageNo, pageLimit }) {

    const whereClouse = {
      AND: [{
        status: 1,
        deletedAt: null
      },
      { jobRoleInstituteMap: { some: { AND: [{ instituteCampusId: instituteCampusId }, { status: 1 }] } } },
      ],
    }
    if (degreeStreamMapId) {
      whereClouse['AND'].push({ degreeStreamMapIds: { array_contains: [degreeStreamMapId] } });
    }
    if (tenthScore) {
      whereClouse['AND'].push({ tenthScore: { lte: tenthScore } });
    }
    if (twelfthScore) {
      whereClouse['AND'].push({ twelfthScore: { lte: twelfthScore } });
    }
    if (UGScore) {
      whereClouse['AND'].push({ UGScore: { lte: UGScore } });
    }
    if (PGScore) {
      whereClouse['AND'].push({ PGScore: { lte: PGScore } });
    }
    if (arrear) {
      whereClouse['AND'].push({ arrearCount: { gte: arrear } });
    }
    if (endBatch) {
      whereClouse['AND'].push({ yearOfPassing: { array_contains: [endBatch] }, })
    }
    if (minCTC != undefined && maxCTC == undefined) {
      whereClouse['AND'].push({ minCompensation: { lte: minCTC } });
      whereClouse['AND'].push({ maxCompensation: { gte: minCTC } });
    }
    if (maxCTC != undefined && minCTC == undefined) {
      whereClouse['AND'].push({ minCompensation: { lte: maxCTC } });
      whereClouse['AND'].push({ maxCompensation: { gte: 0 } });
    }
    if (minCTC != undefined && maxCTC != undefined) {
      whereClouse['AND'].push({ minCompensation: { lte: maxCTC } });
      whereClouse['AND'].push({ maxCompensation: { gte: minCTC } });
    }
    if (jobTypeLevel) {
      whereClouse['AND'].push({ jobTypeLevel: jobTypeLevel });
    }
    if (jobType) {
      whereClouse['AND'].push({ jobType: jobType });
    }
    if (cities) {
      cities = await cities.split(',')
      const cityData = []
      cities.forEach(city => {
        cityData.push({ cities: { array_contains: [{ name: city }] } })
      });
      whereClouse['AND'].push({ OR: cityData })
    }
    if (saved != undefined) {
      whereClouse['AND'].push({ jobRoleStudentMap: { every: { isSaved: saved } } });
    }
    if (searchBy) {
      whereClouse['AND'].push({ tittle: { startsWith: searchBy, mode: 'insensitive', } });
    }
    let counts = await prisma.jobRoles.aggregate({ where: whereClouse, _count: true });
    const count = _.get(counts, '_count', 0);
    const orderBy = { [sort]: order }
    if (count) {
      const query = {
        where: whereClouse,
        select: {
          id: true,
          corporate: {
            select: {
              id: true,
              name: true,
              logo: true
            },
          },
          tittle: true,
          jobTypeLevel: true,
          jobType: true,
          minVacancies: true,
          maxVacancies: true,
          cities: true,
          maxCompensation: true,
          minCompensation: true,
          CTCPeriod: true,
          endDate: true,
          jobRoleStudentMap: {
            where: {
              studentId: studentId
            },
            select: {
              status: true,
              isSaved: true,
              isApplied: true
            }
          }
        },
        skip: pageNo * pageLimit,
        take: pageLimit,
        orderBy
      }
      const result = await prisma.jobRoles.findMany(query);
      result.forEach(element => {
        if (element.jobRoleStudentMap.length < 1) element.jobRoleStudentMap = [{ isApplied: 0, isSaved: 0 }]
      });
      return { result, count, page: pageNo, limit: pageLimit, totalPage: Math.ceil(count / pageLimit) }
    }
    else {
      return { result: [], count, totalPage: 0 }
    }
  }
}

module.exports = JobRole;
