const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();

class RoleRankConfig {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }

  async findMany(id){
    const roleRankConfigData = await prisma.roleRankConfig.findMany({where:{jobId:id}});
    this.data = roleRankConfigData;
    return roleRankConfigData;
  }

}

module.exports = RoleRankConfig;
