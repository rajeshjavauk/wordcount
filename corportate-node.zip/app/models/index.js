const Corporate = require('./Corporate');
const JobRole = require('./JobRoles');
const JobRoleInstituteMap = require('./JobRoleInstituteMap');
const JobRoleStudentMap = require('./JobRoleStudentMap');
const Drive = require('./Drive');
const PoolDriveMap = require('./PoolDriveMap');
const DriveRoleMap = require('./DriveRoleMap');
const DriveInterviewerMap = require('./DriveInterviewerMap');
const Function = require('./Functions');
const Interview = require('./Interview');
const StudentInterviewMap = require('./StudentInterviewMap');

module.exports = {
  Corporate,
  JobRole,
  JobRoleInstituteMap,
  JobRoleStudentMap,
  Drive,
  PoolDriveMap,
  DriveRoleMap,
  DriveInterviewerMap,
  Function,
  Interview,
  StudentInterviewMap
};
