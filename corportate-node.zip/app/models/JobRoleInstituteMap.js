const { PrismaClient } = require('@prisma/client');
const _ = require('lodash');
const prisma = new PrismaClient();


class JobRoleInstituteMap {
  constructor(input, request) {
    this.data = input;
    this.request = request;
  }


  async jobRoleListByInstitute({ status, saved, instituteCampusId, jobTypeLevel, jobType, minVacancies, maxVacancies, minCTC, maxCTC, searchBy, sort = 'createdAt', orderBy = 'desc', pageNo, pageLimit, cities }) {
    const whereClouse = {
      AND: [{
        instituteCampusId,
        jobRoles: { deletedAt: null },
      },{jobRoles: { status: 1 }}],
    }
    if (status != undefined) {
      whereClouse['AND'].push({ status: status });
    }
    if (saved != undefined) {
      whereClouse['AND'].push({  saved: saved });
    }
    if (jobTypeLevel) {
      whereClouse['AND'].push({jobRoles:{ jobTypeLevel: jobTypeLevel }});
    }
    if (jobType) {
      whereClouse['AND'].push({jobRoles:{ jobType: jobType} });
    }
    if (minVacancies != undefined && maxVacancies == undefined) {
      whereClouse['AND'].push({jobRoles:{ minVacancies: { lte: minVacancies } }});
      whereClouse['AND'].push({jobRoles:{ maxVacancies: { gte: minVacancies } }});
    }
    if (maxVacancies != undefined && minVacancies == undefined) {
      whereClouse['AND'].push({ jobRoles:{minVacancies: { lte: maxVacancies }} });
      whereClouse['AND'].push({jobRoles:{ maxVacancies: { gte: 0 } }});
    }
    if (minVacancies != undefined && maxVacancies != undefined) {
      whereClouse['AND'].push({jobRoles:{ minVacancies: { lte: maxVacancies } }});
      whereClouse['AND'].push({ jobRoles:{maxVacancies: { gte: minVacancies }} });
    }
    if (cities) {
      cities = await cities.split(',')
      const cityData = []
      cities.forEach(city => {
        cityData.push({jobRoles:{ cities: {array_contains: [{name:city}],  }} })
      });
      whereClouse['AND'].push({ OR: cityData })
    }

    if (minCTC != undefined && maxCTC == undefined) {
      whereClouse['AND'].push({jobRoles:{ minCompensation: { lte: minCTC }} });
      whereClouse['AND'].push({jobRoles:{ maxCompensation: { gte: minCTC }} });
    }
    if (maxCTC != undefined && minCTC == undefined) {
      whereClouse['AND'].push({jobRoles:{ minCompensation: { lte: maxCTC }} });
      whereClouse['AND'].push({jobRoles:{ maxCompensation: { gte: 0 }} });
    }
    if (minCTC != undefined && maxCTC != undefined) {
      whereClouse['AND'].push({jobRoles:{ minCompensation: { lte: maxCTC }} });
      whereClouse['AND'].push({jobRoles:{ maxCompensation: { gte: minCTC }} });
    }
    if (searchBy) {
      whereClouse['AND'].push({ jobRoles:{tittle: { startsWith: searchBy, mode: 'insensitive', } }})
    }
    let counts = await prisma.jobRoleInstituteMap.aggregate({ where: whereClouse, _count: true });
    const count = _.get(counts, '_count', 0);
    if (count) {
      const query = {
        where: whereClouse,
        select: {
          status:true,
          saved:true,
          instituteCampusId:true,
          jobRoles:{
            select:{
              id: true,
              corporate: {
                select: {
                  id: true,
                  name: true
                },
              },
              tittle: true,
              jobTypeLevel: true,
              jobType: true,
              minVacancies: true,
              maxVacancies: true,
              cities: true,
              maxCompensation: true,
              minCompensation: true,
              CTCPeriod: true,
              postedDate: true,
            }
          }
        },
        skip: pageNo * pageLimit,
        take: pageLimit,
        orderBy: {
          jobRoles:{
             [sort]: orderBy 
          }
        }
      }
      const result = await prisma.jobRoleInstituteMap.findMany(query);
      return { result, count, page: pageNo, limit: pageLimit, totalPage: Math.ceil(count / pageLimit) }
    }
    else {
      return { result: [], count, totalPage: 0 }
    }
  }




}

module.exports = JobRoleInstituteMap;
