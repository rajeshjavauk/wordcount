const common = require('./common');


module.exports = async (fastify) => {
  fastify.log.info('Registering the routes started');
  await common(fastify);
  
  fastify.log.info('Registering the routes completed');
};
