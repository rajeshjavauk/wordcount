const { utils } = require('../helpers');
const { common } = require('../handlers');
const { corporate, jobRole} = require('../schemas');

module.exports = async (fastify) => {
  fastify.log.info('Common route registration started');
  await utils.routesRegister(fastify, [
    {
      method: 'GET',
      path: '/health',
      schema: {
        description: 'This is an endpoint for application health check',
        tags: ['health'],
        response: {
          200: {
            description: 'Success Response',
            type: 'object',
            properties: {
              msg: { type: 'string' },
            },
          },
        },
      },
      handler: (request, reply) => {
        reply.send({ msg: 'The Application is Up and Running' });
      },
    },
    {
      method: 'GET',
      path: '/corporates-report/lists',
      schema: corporate.getCorporateSchema,
      handler: common.getCorporateList,
    },
    {
      method: 'GET',
      path: '/corporates-report/:corporateId',
      schema: corporate.getCorporateByIdSchema,
      handler: common.getCorporateById,
    },
    {
      method: 'GET',
      path: '/corporates-report/:corporateId/jobs/lists',
      schema: jobRole.getJobByCorpIdSchema,
      handler: common.getJobRoleList,
    },
  ]);
  fastify.log.info('Common route registration completed');
};  