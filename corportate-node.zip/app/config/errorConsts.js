exports.CORPORATE = {
  NOT_FOUND: 'There is no active corporate with provided id',
};
