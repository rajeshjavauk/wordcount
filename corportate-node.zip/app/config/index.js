/* eslint-disable global-require */
require('dotenv').config();

exports.server = {
  port: process.env.PORT,
  host: process.env.HOST,
  AUDIENCE:process.env.AUDIENCE,
  ISSUER:process.env.ISSUER,
  ALGORITHM :process.env.ALGORITHM,
  LOGIN_SECRET_KEY: process.env.LOGIN_SECRET_KEY,
  LOGIN_TOKEN_EXPIRES_IN: process.env.LOGIN_TOKEN_EXPIRES_IN,
  AWS_REGION: process.env.AWS_REGION,
  AWS_SQS_URL:process.env.AWS_SQS_URL,
  AWS_ACCESS_KEY: process.env.AWS_ACCESS_KEY,
  AWS_SECRET_KEY: process.env.AWS_SECRET_KEY,
  cors: {
    origin: '*',
  },
};

exports.swagger = {
  routePrefix: '/doc',
  exposeRoute: true,
  swagger: {
    info: {
      title: 'Pluginlive Corporate swagger',
      version: '2.0.0',
    },
    externalDocs: {
      url: 'https://swagger.io',
      description: 'Find more info here',
    },
    host: process.env.HOST,
    schemes: ['http','https'],
    consumes: ['application/json'],
    produces: ['application/json'],
  },
};



exports.beBaseUrl = {
  AUTH: process.env.AUTH_BE_BASE_URL,
  CORPORATE: process.env.CORPORATE_BE_BASE_URL,
  INSTITUTE: process.env.INSTITUTE_BE_BASE_URL,
  STUDENT: process.env.STUDENT_BE_BASE_URL,
};

exports.errors = {
  consts: require('./errorConsts'),
};

exports.response = {
  messages: require('./responseMessage'),
};
