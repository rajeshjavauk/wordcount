const _ = require('lodash');
const { Corporate, JobRole, JobRoleInstituteMap, JobRoleStudentMap, DriveRoleMap, Function } = require('../models');
const { errors, response } = require('../config');
const { utils, jobRoles } = require('../helpers');
const { sendSQS, sendMsgSQS } = require('../helpers/sqsJobrole');
const { mapStudentDataforjobList } = require('../helpers/jobRoles');
const RoleRankConfig = require('../models/RoleRankConfig');

const errorConsts = errors.consts;
const { messages } = response;

exports.getCorporateById = async (req, res) => {
  try {
    const { params } = req;
    const corporate = new Corporate({}, req);
    const corporateData = await corporate.getById(params.corporateId);
    if (_.get(corporateData, 'deletedAt', true) || !_.get(corporateData, 'isActive')) {
      utils.sendResponse(res, 400, errorConsts.CORPORATE.NOT_FOUND, {}, {});
      return;
    }
    utils.sendResponse(res, 200, messages.COMMON.SUCCESS, corporateData, {});
  } catch (err) {
    utils.sendResponse(res, 500, err.message, {}, err);
  }
};

exports.getCorporateList = async (req, res) => {
  try {
    const { params, query } = req;
    const corporate = new Corporate({}, req);
    const corporateList = await corporate.list(query);
    utils.sendResponse(res, 200, messages.COMMON.SUCCESS, corporateList, {});
  } catch (err) {
    utils.sendResponse(res, 500, err.message, {}, err);
  }
};

exports.getJobRoleList = async (req, res) => {
  try {
    const { params, query } = req;
    const { corporateId } = params;
    const corporate = new Corporate({}, req);
    const corporateData = await corporate.getById(corporateId);
    if (_.get(corporateData, 'deletedAt', true) || !_.get(corporateData, 'isActive')) {
      utils.sendResponse(res, 400, errorConsts.CORPORATE.NOT_FOUND, {}, {});
      return;
    }
    _.set(query, 'corporateId', corporateId);
    const jobRole = new JobRole({}, req);
    const jobRoleList = await jobRole.list(query)
    utils.sendResponse(res, 200, messages.COMMON.SUCCESS, jobRoleList, {});

  } catch (err) {
    console.log(20, err);
    utils.sendResponse(res, err.status ? err.status : 500, err.message, {}, err);
  }
};