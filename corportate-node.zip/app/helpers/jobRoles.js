const _ = require('lodash');

exports.mapRequestBodyToCreateModel = (requestBody) => {
  const jobDetails = _.get(requestBody, 'jobDetails', {});
  const CTCDetails = _.get(requestBody, 'ctc', {});
  const jobLocatoin = _.get(requestBody, 'jobLocation', {});
  const elgibilty = _.get(requestBody, 'elgibilty', {});
  const jobRoleModel = {
    ...jobDetails,
    CTCPeriod: CTCDetails.period,
    minCompensation: Math.min(...CTCDetails.tiers.map(item => item.min)),
    maxCompensation: Math.max(...CTCDetails.tiers.map(item => item.max ? item.max : item.min)),
    CTC: CTCDetails.tiers,
    CTCIsTierBased: CTCDetails.isTierBased,
    ...jobLocatoin,
    degreeStreamMapIds: elgibilty.degreeStreamMapIds,
    isArrearsAllowed: elgibilty.isArrearsAllowed,
    arrearCondition: _.get(elgibilty, 'arrearCount.condition', null),
    arrearCount: _.get(elgibilty, 'arrearCount.count', 0),
    mandatorySkills: elgibilty.mandatorySkills,
    optionalSkills: elgibilty.optionalSkills,
    yearOfPassing: elgibilty.yearOfPassing,
    scoreCondition: _.get(elgibilty, 'scores.condition'),
    avgScore: _.get(elgibilty, 'scores.avg', 0),
    tenthScore: _.get(elgibilty, 'scores.tenth', 0),
    twelfthScore: _.get(elgibilty, 'scores.twelfth', 0),
    UGScore: _.get(elgibilty, 'scores.UG', 0),
    PGScore: _.get(elgibilty, 'scores.PG', 0),
    interviewWorkFlow: _.get(requestBody, 'interviewWorkFlow', {}),
  };
  jobRoleModel.startDate = new Date(jobDetails.startDate);
  jobRoleModel.endDate = new Date(jobDetails.endDate);
  return jobRoleModel;
};

exports.jobRoleViewUpdates = async (request, prisma) => {
  try {
    const jobRoleMetricView = 'job_role_metric';
    request.log.info(`updating ${jobRoleMetricView}`);
    const refreshQuery = `REFRESH MATERIALIZED VIEW ${jobRoleMetricView}`;
    const affectedCount = await prisma.$executeRawUnsafe(refreshQuery);
    request.log.info({ affectedCount }, `updated ${jobRoleMetricView}`);
  } catch (err) {
    request.log.error(err, 'there is while updating job role views');
  }
};

exports.mapStudentDataforjobList = async (studentDetails) => {
  const jobRoleCriteria = {
    studentId: studentDetails.id,
    instituteCampusId: studentDetails.instituteCampusId,
    degreeStreamMapId: studentDetails.currentCourse.degreeStreamMapId,
    arrear: studentDetails.currentCourse.noOfArrears,
    endBatch: new Date(Number(studentDetails.currentCourse.endedOn)).getFullYear()
  }
  studentDetails.educationProfile.forEach(education => {
    let marks = Number(education.marks)
    if (education.cumulativeType == 'CGPA') {
      marks = Number(education.marks * 10);
    }
    if (education.educationLevel == 'tenth') jobRoleCriteria.tenthScore = marks;
    if (education.educationLevel == 'twelfth') jobRoleCriteria.twelfthScore = marks;
    if (education.educationLevel == 'ug') jobRoleCriteria.UGScore = marks;
    if (education.educationLevel == 'pg') jobRoleCriteria.PGScore = marks;
  });
  return jobRoleCriteria;
}

exports.initialRoleRankingConfiguration = async (jobRole) => {
  let interviewFlowData = [{ jobId: jobRole.id, name: 'Academics' }, { jobId: jobRole.id, name: 'Institute' }, { jobId: jobRole.id, name: 'Internship' }, { jobId: jobRole.id, name: 'Work Experience' }, { jobId: jobRole.id, name: 'External Training courses' }];
  jobRole.interviewWorkFlow.rounds.forEach(element => {
    if (element.type == 'ASSESMENT') {
      interviewFlowData.push({ jobId: jobRole.id, name: element.name })
    }
  });
  let eachRoundAllotment = (100 / interviewFlowData.length)
  let FirstObjAllotment = eachRoundAllotment
  if (eachRoundAllotment % 1 != 0) {
    let value = eachRoundAllotment.toString().split('.');
    eachRoundAllotment = value[0];
    FirstObjAllotment = (100 - (Number(interviewFlowData.length) * Number(eachRoundAllotment))) + Number(eachRoundAllotment);
  }
  interviewFlowData.forEach(async (element, index) => {
    element.order = index < 5 ? 0 : index - 4;
    element.roundAllotment = index == 0 ? Number(FirstObjAllotment) : Number(eachRoundAllotment)
  });
  return interviewFlowData
}