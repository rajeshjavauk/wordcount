const config = require('../config');
const jwt = require("jsonwebtoken");
const  {LOGIN_TOKEN_EXPIRES_IN,LOGIN_SECRET_KEY,ALGORITHM,ISSUER,AUDIENCE}= config.server


exports.routesRegister = async (fastify, routes = []) => {
  if (!Array.isArray(routes)) {
    throw new Error('routes must be an array');
  }
  routes.forEach((ro) => {
    fastify.route(ro);
  });
};

exports.sendResponse = (replay, statusCode, message,data = {}, error = {}) => {
  replay.code(statusCode).send({
    message,
    data,
    error,
  });
};

exports.verifyToken=async (token)=> {
  try {
      let payload = jwt.verify(token, LOGIN_SECRET_KEY, {
          algorithm: ALGORITHM,
          expiresIn: LOGIN_TOKEN_EXPIRES_IN,
          issuer: ISSUER,
          audience: AUDIENCE,
      });
      return payload.user;
  } catch (error) {
      throw {message:'Missing or invalid authentication token',error};
  }
}