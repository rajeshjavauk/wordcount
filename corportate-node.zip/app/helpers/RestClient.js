const axios = require('axios');
const _ = require('lodash');

class RestClient {
  #httpClient;

  constructor(baseUrl, request) {
    this.#httpClient = axios.create({
      baseURL: baseUrl,
    });
    this.request = request;
  }

  async doPost(url, data, options = {}) {
    try {
      const headers = _.get(options, 'headers', {});
      const response = await this.#httpClient.post(url, data, { headers });
      return response;
    } catch (err) {
      if(err&&err.response&&err.response.data)
      err.message=err.response.data.message
      throw err;
    }
  }

  async doGet(url, data, options = {}) {
    try {
      const headers = _.get(options, 'headers', {});
      const response = await this.#httpClient.get(url, data, { headers });
      return response;
    } catch (err) {
      if(err&&err.response&&err.response.data)
      err.message=err.response.data.message
      throw err;
    }
  }
  async doPut(url, data, options = {}) {
    try {
      const headers = _.get(options, 'headers', {});
      const response = await this.#httpClient.put(url, data, { headers });
      return response;
    } catch (err) {
      if(err&&err.response&&err.response.data)
      err.message=err.response.data.message
      throw err;
    }
  }

}

module.exports = RestClient;
