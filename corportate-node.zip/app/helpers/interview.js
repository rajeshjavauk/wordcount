exports.studentInterviewMap = async ( {studentIds,interviewerIds,date,time,duration,mode,link,instructions},interviewId,interviewScheduler) => {
const studentInterviewMapData=[];
    studentIds.forEach(studentId => {
        let obj =  {studentId,interviewerIds,date:new Date(date),time,duration,mode,link,instructions,interviewId,interviewScheduler}
        studentInterviewMapData.push(obj);
    });
    return studentInterviewMapData
}