const AWS = require('aws-sdk');
const { server } = require('../config');
const { JobRoleInstituteMap } = require('../models');
const SQS_CONFIG = {
    apiVersion: '2012-11-05',
    accessKeyId: server.AWS_ACCESS_KEY,
    secretAccessKey: server.AWS_SECRET_KEY,
    region: server.AWS_REGION,
};


exports.sendMsgSQS = async (data) => {
    try {
        var sqs = new AWS.SQS(SQS_CONFIG);
        let params = {
            QueueUrl: server.AWS_SQS_URL,
            MessageBody: JSON.stringify(data),
        }
        return sqs.sendMessage(params).promise().then((data) => { return data }).catch((err) => { throw err; });

    } catch (err) {
        console.log(err)
    }
}


exports.receiveMsgSQS = async () => {

    try {
        var sqs = new AWS.SQS(SQS_CONFIG);
        let params = {
            QueueUrl: server.AWS_SQS_URL,
            VisibilityTimeout: 20,
            WaitTimeSeconds: 10
        };

        const recivedMsg = sqs.receiveMessage(params).promise().then(data => { return data }).catch((err) => { console.log(err); });
        return recivedMsg

    } catch (err) {
        console.log(err)
    }
}

exports.deleteMsgSQS = async (data) => {
    try {
        if(!data.Messages){
            return;
        }
        var sqs = new AWS.SQS(SQS_CONFIG);
        var deleteParams = {
            QueueUrl: server.AWS_SQS_URL,
            ReceiptHandle: data.Messages[0].ReceiptHandle
        };
        sqs.deleteMessage(deleteParams, function (err, data) {
            if (err) {
                console.log("Delete Error", err);
            } else {
                console.log("Message Deleted", data);
            }
        });
    } catch (err) {
        console.log(err)
    }
}