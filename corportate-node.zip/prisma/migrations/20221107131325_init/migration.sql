-- AlterEnum
ALTER TYPE "instituteStatus" ADD VALUE 'REQUESTED';
