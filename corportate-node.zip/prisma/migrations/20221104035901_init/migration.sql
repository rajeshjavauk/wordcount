-- CreateEnum
CREATE TYPE "_corporateType" AS ENUM ('STARTUP', 'ESTABLISHED');

-- CreateEnum
CREATE TYPE "_scoreCondition" AS ENUM ('LTE', 'ET', 'GTE');

-- CreateEnum
CREATE TYPE "_rejectedReason" AS ENUM ('SALARY_LOW', 'LOCATION_FAR', 'NOT_INTRESTED_CORPORATE', 'OTHER');

-- CreateEnum
CREATE TYPE "_arrearCondition" AS ENUM ('LTE', 'ET', 'GTE');

-- CreateEnum
CREATE TYPE "_CTCPeriod" AS ENUM ('ANNUALLY', 'MONTHLY');

-- CreateEnum
CREATE TYPE "_jobTypeLevel" AS ENUM ('ENTRY', 'INTERN');

-- CreateEnum
CREATE TYPE "_jobType" AS ENUM ('FULL', 'PART', 'HYBRID');

-- CreateEnum
CREATE TYPE "_applyRoleStatus" AS ENUM ('ACTIVE', 'SHORTLISTED', 'REJECTED', 'OFFER_RECEIVED');

-- CreateEnum
CREATE TYPE "DriveMode" AS ENUM ('CAMPUS_DRIVE', 'POOL_DRIVE', 'VIRTUAL_DRIVE');

-- CreateEnum
CREATE TYPE "corporateStatus" AS ENUM ('PENDING', 'REQUESTED', 'CONFIRMED', 'CANCELLED');

-- CreateEnum
CREATE TYPE "instituteStatus" AS ENUM ('PENDING', 'CONFIRMED', 'RESCHEDULE_REQUESTED', 'CANCELLED');

-- CreateTable
CREATE TABLE "corporates" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_up" TIMESTAMP(3) NOT NULL,
    "name" TEXT NOT NULL,
    "logo" TEXT,
    "industry" TEXT NOT NULL,
    "address_line1" TEXT NOT NULL,
    "address_line2" TEXT,
    "city" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "postal_code" TEXT NOT NULL,
    "website" TEXT NOT NULL,
    "contact_number" TEXT NOT NULL,
    "contact_email" TEXT NOT NULL,
    "corporate_type" "_corporateType" NOT NULL DEFAULT 'ESTABLISHED',
    "pan" TEXT NOT NULL,
    "sector" TEXT NOT NULL,
    "regDocs" JSONB,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "deleted_at" TIMESTAMP(3),

    CONSTRAINT "corporates_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "job_roles" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "tittle" TEXT NOT NULL,
    "function" TEXT,
    "job_type_level" "_jobTypeLevel" NOT NULL DEFAULT 'ENTRY',
    "job_type" "_jobType" NOT NULL DEFAULT 'FULL',
    "description" TEXT NOT NULL,
    "min_vacancies" INTEGER NOT NULL,
    "max_vacancies" INTEGER NOT NULL,
    "start_date" TIMESTAMP(3) NOT NULL,
    "end_date" TIMESTAMP(3) NOT NULL,
    "ctc_period" "_CTCPeriod" NOT NULL DEFAULT 'ANNUALLY',
    "CTC" JSONB NOT NULL,
    "min_compensation" DECIMAL(65,30) NOT NULL DEFAULT 0,
    "max_compensation" DECIMAL(65,30) NOT NULL DEFAULT 0,
    "ctc_is_tier_based" BOOLEAN NOT NULL DEFAULT false,
    "citites" JSONB NOT NULL,
    "is_remote_allowed" BOOLEAN NOT NULL DEFAULT false,
    "remote_cities" JSONB NOT NULL,
    "degree_stream_map_ids" JSONB NOT NULL,
    "is_arrears_allowed" BOOLEAN NOT NULL DEFAULT false,
    "arrear_condition" "_arrearCondition" NOT NULL DEFAULT 'LTE',
    "arrear_count" INTEGER NOT NULL DEFAULT 0,
    "mandatory_skills" JSONB,
    "optional_skills" JSONB,
    "year_of_passing" JSONB NOT NULL,
    "score_condition" "_scoreCondition" NOT NULL DEFAULT 'GTE',
    "avg_scroe" INTEGER NOT NULL,
    "tenth_score" INTEGER NOT NULL,
    "twelth_score" INTEGER NOT NULL,
    "ug_score" INTEGER NOT NULL,
    "pg_score" INTEGER NOT NULL,
    "interview_workflow" JSONB NOT NULL,
    "posted_date" TIMESTAMP(3),
    "deleted_at" TIMESTAMP(3),
    "corporate_id" TEXT NOT NULL,
    "status" INTEGER NOT NULL DEFAULT 0,
    "sqs_msg_id" TEXT,

    CONSTRAINT "job_roles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "job_role_institute_map" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "institute_campus_id" TEXT NOT NULL,
    "status" INTEGER NOT NULL DEFAULT 0,
    "saved" INTEGER NOT NULL DEFAULT 0,
    "rejected_reason" "_rejectedReason",
    "other_reason" TEXT,
    "job_id" TEXT NOT NULL,

    CONSTRAINT "job_role_institute_map_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "job_role_student_map" (
    "id" TEXT NOT NULL,
    "student_id" TEXT NOT NULL,
    "role_id" TEXT NOT NULL,
    "is_applied" INTEGER NOT NULL DEFAULT 0,
    "is_saved" INTEGER NOT NULL DEFAULT 0,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3) NOT NULL,
    "_applyRoleStatus" "_applyRoleStatus" NOT NULL DEFAULT 'ACTIVE',
    "rejected_reason" "_rejectedReason",

    CONSTRAINT "job_role_student_map_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "drives" (
    "id" TEXT NOT NULL,
    "corporate_id" TEXT NOT NULL,
    "mode" "DriveMode" NOT NULL DEFAULT 'CAMPUS_DRIVE',
    "student_min_rating" TEXT NOT NULL,
    "min_score" INTEGER NOT NULL,
    "degree_department" JSONB NOT NULL,
    "start_date" TIMESTAMP(3),
    "end_date" TIMESTAMP(3),
    "corporate_status" "corporateStatus" NOT NULL DEFAULT 'PENDING',
    "city" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "host_college_id" TEXT NOT NULL,
    "institute_status" "instituteStatus" NOT NULL DEFAULT 'PENDING',

    CONSTRAINT "drives_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "pool_drive_institute_campus_map" (
    "id" TEXT NOT NULL,
    "drive_id" TEXT NOT NULL,
    "institute_campus_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "pool_drive_institute_campus_map_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "drive_role_map" (
    "id" TEXT NOT NULL,
    "drive_id" TEXT NOT NULL,
    "role_id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "drive_role_map_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "job_role_student_map_student_id_role_id_key" ON "job_role_student_map"("student_id", "role_id");

-- AddForeignKey
ALTER TABLE "job_roles" ADD CONSTRAINT "job_roles_corporate_id_fkey" FOREIGN KEY ("corporate_id") REFERENCES "corporates"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "job_role_institute_map" ADD CONSTRAINT "job_role_institute_map_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "job_role_student_map" ADD CONSTRAINT "job_role_student_map_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "drives" ADD CONSTRAINT "drives_corporate_id_fkey" FOREIGN KEY ("corporate_id") REFERENCES "corporates"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "pool_drive_institute_campus_map" ADD CONSTRAINT "pool_drive_institute_campus_map_drive_id_fkey" FOREIGN KEY ("drive_id") REFERENCES "drives"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "drive_role_map" ADD CONSTRAINT "drive_role_map_drive_id_fkey" FOREIGN KEY ("drive_id") REFERENCES "drives"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "drive_role_map" ADD CONSTRAINT "drive_role_map_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
