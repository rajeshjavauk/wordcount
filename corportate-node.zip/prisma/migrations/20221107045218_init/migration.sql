/*
  Warnings:

  - Added the required column `host_college_name` to the `drives` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "drives" ADD COLUMN     "host_college_name" TEXT NOT NULL;
