-- AlterTable
ALTER TABLE "student_interview" ALTER COLUMN "link" DROP NOT NULL,
ALTER COLUMN "instructions" DROP NOT NULL;
