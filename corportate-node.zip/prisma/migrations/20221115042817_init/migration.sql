-- AlterTable
ALTER TABLE "drive_interviewer_map" ADD COLUMN     "deleted_at" TIMESTAMP(3);

-- AlterTable
ALTER TABLE "drives" ALTER COLUMN "student_min_rating" DROP NOT NULL,
ALTER COLUMN "min_score" DROP NOT NULL,
ALTER COLUMN "degree_department" DROP NOT NULL,
ALTER COLUMN "city" DROP NOT NULL;
