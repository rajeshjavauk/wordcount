-- AlterTable
ALTER TABLE "drive_role_candidate_map" ALTER COLUMN "offerStatus" DROP NOT NULL;

-- AlterTable
ALTER TABLE "drives" ADD COLUMN     "serial_no" SERIAL NOT NULL;

-- CreateTable
CREATE TABLE "interview" (
    "id" TEXT NOT NULL,
    "drive_id" TEXT NOT NULL,
    "role_id" TEXT NOT NULL,
    "interview_round" TEXT NOT NULL,
    "interview_type" TEXT NOT NULL,

    CONSTRAINT "interview_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "student_interview" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "studentId" TEXT NOT NULL,
    "interviewerId" JSONB NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "time" TEXT NOT NULL,
    "duration" TEXT NOT NULL,
    "mode" TEXT NOT NULL,
    "link" TEXT NOT NULL,
    "instructions" TEXT NOT NULL,
    "interview_id" TEXT NOT NULL,

    CONSTRAINT "student_interview_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "interview_drive_id_role_id_interview_round_key" ON "interview"("drive_id", "role_id", "interview_round");

-- CreateIndex
CREATE UNIQUE INDEX "student_interview_studentId_interview_id_key" ON "student_interview"("studentId", "interview_id");

-- AddForeignKey
ALTER TABLE "interview" ADD CONSTRAINT "interview_drive_id_fkey" FOREIGN KEY ("drive_id") REFERENCES "drives"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "interview" ADD CONSTRAINT "interview_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "student_interview" ADD CONSTRAINT "student_interview_interview_id_fkey" FOREIGN KEY ("interview_id") REFERENCES "interview"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
