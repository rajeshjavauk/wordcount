/*
  Warnings:

  - You are about to drop the column `ranking` on the `drive_role_candidate_map` table. All the data in the column will be lost.
  - You are about to drop the column `degree_department` on the `drives` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "drive_role_candidate_map" DROP COLUMN "ranking";

-- AlterTable
ALTER TABLE "drives" DROP COLUMN "degree_department",
ADD COLUMN     "degree_stream_map_id" JSONB;

-- AlterTable
ALTER TABLE "role_rank_config" ADD COLUMN     "order" INTEGER;
