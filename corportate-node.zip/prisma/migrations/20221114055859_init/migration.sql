/*
  Warnings:

  - The values [REJECT] on the enum `_candidateStatusOnDrive` will be removed. If these variants are still used in the database, this will fail.
  - You are about to drop the column `role_id` on the `drive_interviewer_map` table. All the data in the column will be lost.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "_candidateStatusOnDrive_new" AS ENUM ('ACTIVE', 'HOLD', 'REJECTED', 'SHORTLISTED');
ALTER TABLE "drive_role_candidate_map" ALTER COLUMN "status" DROP DEFAULT;
ALTER TABLE "drive_role_candidate_map" ALTER COLUMN "status" TYPE "_candidateStatusOnDrive_new" USING ("status"::text::"_candidateStatusOnDrive_new");
ALTER TYPE "_candidateStatusOnDrive" RENAME TO "_candidateStatusOnDrive_old";
ALTER TYPE "_candidateStatusOnDrive_new" RENAME TO "_candidateStatusOnDrive";
DROP TYPE "_candidateStatusOnDrive_old";
ALTER TABLE "drive_role_candidate_map" ALTER COLUMN "status" SET DEFAULT 'ACTIVE';
COMMIT;

-- DropForeignKey
ALTER TABLE "drive_interviewer_map" DROP CONSTRAINT "drive_interviewer_map_role_id_fkey";

-- AlterTable
ALTER TABLE "drive_interviewer_map" DROP COLUMN "role_id";

-- CreateTable
CREATE TABLE "role_rank_config" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "job_id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "round_allotment" TEXT NOT NULL,

    CONSTRAINT "role_rank_config_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "role_rank_config" ADD CONSTRAINT "role_rank_config_job_id_fkey" FOREIGN KEY ("job_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
