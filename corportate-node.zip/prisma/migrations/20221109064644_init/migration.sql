-- AlterTable
ALTER TABLE "corporates" ADD COLUMN     "city_id" TEXT,
ADD COLUMN     "country" TEXT,
ADD COLUMN     "country_id" TEXT,
ADD COLUMN     "state_id" TEXT,
ALTER COLUMN "city" DROP NOT NULL,
ALTER COLUMN "state" DROP NOT NULL;

-- AlterTable
ALTER TABLE "drives" ADD COLUMN     "city_id" TEXT;
