-- CreateEnum
CREATE TYPE "_candidateStatusOnDrive" AS ENUM ('ACTIVE', 'HOLD', 'REJECT', 'SHORTLISTED');

-- CreateTable
CREATE TABLE "drive_role_candidate_map" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "drive_id" TEXT NOT NULL,
    "role_id" TEXT NOT NULL,
    "ranking" DECIMAL(65,30) NOT NULL,
    "student_id" TEXT NOT NULL,
    "status" "_candidateStatusOnDrive" NOT NULL DEFAULT 'ACTIVE',
    "stage" TEXT NOT NULL,
    "offer" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "drive_role_candidate_map_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "drive_interviewer_map" (
    "id" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "drive_id" TEXT NOT NULL,
    "role_id" TEXT NOT NULL,
    "interviewer_id" TEXT NOT NULL,

    CONSTRAINT "drive_interviewer_map_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "drive_role_candidate_map_drive_id_role_id_student_id_key" ON "drive_role_candidate_map"("drive_id", "role_id", "student_id");

-- CreateIndex
CREATE UNIQUE INDEX "drive_interviewer_map_drive_id_interviewer_id_key" ON "drive_interviewer_map"("drive_id", "interviewer_id");

-- AddForeignKey
ALTER TABLE "drive_role_candidate_map" ADD CONSTRAINT "drive_role_candidate_map_drive_id_fkey" FOREIGN KEY ("drive_id") REFERENCES "drives"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "drive_role_candidate_map" ADD CONSTRAINT "drive_role_candidate_map_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "drive_interviewer_map" ADD CONSTRAINT "drive_interviewer_map_drive_id_fkey" FOREIGN KEY ("drive_id") REFERENCES "drives"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "drive_interviewer_map" ADD CONSTRAINT "drive_interviewer_map_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "job_roles"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
