-- AlterTable
ALTER TABLE "job_roles" ALTER COLUMN "remote_cities" DROP NOT NULL;
