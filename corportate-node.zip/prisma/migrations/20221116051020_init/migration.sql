-- AlterEnum
ALTER TYPE "corporateStatus" ADD VALUE 'RESCHEDULE_REQUESTED';
