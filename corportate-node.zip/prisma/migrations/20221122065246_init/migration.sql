-- AlterTable
ALTER TABLE "drives" ADD COLUMN     "corporate_reason" TEXT,
ADD COLUMN     "institute_reason" TEXT;
