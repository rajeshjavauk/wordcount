-- AlterTable
ALTER TABLE "student_interview" ADD COLUMN     "interviewScheduler" TEXT;
