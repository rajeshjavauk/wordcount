/*
  Warnings:

  - Made the column `avg_scroe` on table `job_roles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `tenth_score` on table `job_roles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `twelth_score` on table `job_roles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `ug_score` on table `job_roles` required. This step will fail if there are existing NULL values in that column.
  - Made the column `pg_score` on table `job_roles` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "job_roles" ALTER COLUMN "avg_scroe" SET NOT NULL,
ALTER COLUMN "tenth_score" SET NOT NULL,
ALTER COLUMN "twelth_score" SET NOT NULL,
ALTER COLUMN "ug_score" SET NOT NULL,
ALTER COLUMN "pg_score" SET NOT NULL;
