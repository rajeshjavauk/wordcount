/*
  Warnings:

  - You are about to drop the column `interviewerId` on the `student_interview` table. All the data in the column will be lost.
  - Added the required column `interviewerIds` to the `student_interview` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "student_interview" DROP COLUMN "interviewerId",
ADD COLUMN     "interviewerIds" JSONB NOT NULL;
