/*
  Warnings:

  - The `corporate_type` column on the `corporates` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- CreateEnum
CREATE TYPE "corporateType" AS ENUM ('STARTUP', 'ESTABLISHED');

-- AlterTable
ALTER TABLE "corporates" DROP COLUMN "corporate_type",
ADD COLUMN     "corporate_type" "corporateType" NOT NULL DEFAULT 'ESTABLISHED';

-- DropEnum
DROP TYPE "_corporateType";
