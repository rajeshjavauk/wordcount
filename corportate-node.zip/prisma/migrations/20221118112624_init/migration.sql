/*
  Warnings:

  - You are about to drop the column `ranking` on the `drive_role_candidate_map` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "drive_role_candidate_map" DROP COLUMN "ranking";
