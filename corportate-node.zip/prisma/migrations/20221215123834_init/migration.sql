-- AlterTable
ALTER TABLE "job_roles" ALTER COLUMN "avg_scroe" DROP NOT NULL,
ALTER COLUMN "tenth_score" DROP NOT NULL,
ALTER COLUMN "twelth_score" DROP NOT NULL,
ALTER COLUMN "ug_score" DROP NOT NULL,
ALTER COLUMN "pg_score" DROP NOT NULL;
