-- AlterTable
ALTER TABLE "drives" ADD COLUMN     "end_time" TEXT,
ADD COLUMN     "start_time" TEXT;
