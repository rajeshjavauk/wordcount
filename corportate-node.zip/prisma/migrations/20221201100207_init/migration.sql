/*
  Warnings:

  - The values [RESCHEDULE_REQUESTED] on the enum `corporateStatus` will be removed. If these variants are still used in the database, this will fail.

*/
-- AlterEnum
BEGIN;
CREATE TYPE "corporateStatus_new" AS ENUM ('PENDING', 'REQUESTED', 'CONFIRMED', 'CANCELLED', 'COMPLETED', 'ONGOING');
ALTER TABLE "drives" ALTER COLUMN "corporate_status" DROP DEFAULT;
ALTER TABLE "drives" ALTER COLUMN "corporate_status" TYPE "corporateStatus_new" USING ("corporate_status"::text::"corporateStatus_new");
ALTER TYPE "corporateStatus" RENAME TO "corporateStatus_old";
ALTER TYPE "corporateStatus_new" RENAME TO "corporateStatus";
DROP TYPE "corporateStatus_old";
ALTER TABLE "drives" ALTER COLUMN "corporate_status" SET DEFAULT 'REQUESTED';
COMMIT;

-- AlterTable
ALTER TABLE "drives" ALTER COLUMN "corporate_status" SET DEFAULT 'REQUESTED',
ALTER COLUMN "institute_status" SET DEFAULT 'PENDING';
