/*
  Warnings:

  - Added the required column `ranking` to the `drive_role_candidate_map` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "drive_role_candidate_map" ADD COLUMN     "ranking" DECIMAL(65,30) NOT NULL;
