-- AlterTable
ALTER TABLE "drives" ALTER COLUMN "institute_status" SET DEFAULT 'REQUESTED';
