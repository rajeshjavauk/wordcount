/*
  Warnings:

  - Changed the type of `round_allotment` on the `role_rank_config` table. No cast exists, the column would be dropped and recreated, which cannot be done if there is data, since the column is required.

*/
-- AlterTable
ALTER TABLE "role_rank_config" DROP COLUMN "round_allotment",
ADD COLUMN     "round_allotment" INTEGER NOT NULL;
