-- AlterTable
ALTER TABLE "job_roles" ADD COLUMN     "duplicated_job_id" TEXT;
