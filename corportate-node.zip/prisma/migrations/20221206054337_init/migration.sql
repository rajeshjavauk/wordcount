/*
  Warnings:

  - You are about to drop the column `degree_stream_map_id` on the `drives` table. All the data in the column will be lost.
  - You are about to drop the column `min_score` on the `drives` table. All the data in the column will be lost.
  - You are about to drop the column `student_min_rating` on the `drives` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "drive_role_map" ADD COLUMN     "degree_stream_map_id" JSONB,
ADD COLUMN     "min_score" INTEGER,
ADD COLUMN     "student_min_rating" TEXT;

-- AlterTable
ALTER TABLE "drives" DROP COLUMN "degree_stream_map_id",
DROP COLUMN "min_score",
DROP COLUMN "student_min_rating";
