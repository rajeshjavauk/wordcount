-- CreateTable
CREATE TABLE "function" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "function_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "designation" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "function_id" TEXT NOT NULL,
    "is_active" BOOLEAN NOT NULL DEFAULT true,
    "created_at" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "designation_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "function_name_key" ON "function"("name");

-- CreateIndex
CREATE UNIQUE INDEX "designation_name_function_id_key" ON "designation"("name", "function_id");

-- AddForeignKey
ALTER TABLE "designation" ADD CONSTRAINT "designation_function_id_fkey" FOREIGN KEY ("function_id") REFERENCES "function"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
