/* eslint-disable global-require */
const Fastify = require('fastify');
const routes = require('./app/routes');
const config = require('./app/config');

const fastify = Fastify({
  logger: true,
  ajv: {
    plugins: [require('ajv-formats')],
  },
});

// set the loger as global
global.logger = fastify.log;

fastify.register(require('@fastify/cors'), config.server.cors);
fastify.register(require('@fastify/helmet'));
/**
 * Run the server!
 */
async function start() {
  try {
    // eslint-disable-next-line global-require
    await fastify.register(require('@fastify/swagger'), config.swagger);
    // register the routes
    await fastify.register(routes);
    fastify.swagger();
    await fastify.listen({ port: config.server.port, host: config.server.host });
    // eslint-disable-next-line no-console
    console.log(fastify.printRoutes());
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
}
start();
