const data = require('./seederData.json')
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

seedData = async () => {
    try {
        for (fun of data) {
            const obj = { name: fun.name, designations: { create: fun.designations } }
            await prisma.functions.upsert({ where: { name: fun.name }, update: obj, create: obj }).catch(error => { })
        }
        console.log("Jobs and designations seeded")
        
    } catch (err) {
        console.log(err)
    }
}

seedData();