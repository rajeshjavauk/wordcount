const { receiveMsgSQS, deleteMsgSQS } = require("../app/helpers/sqsJobrole");
const { JobRoleInstituteMap } = require("../app/models");
async function receivedMsgFromSQS(){
    const recivedMsg= await receiveMsgSQS() 
    if(!recivedMsg.Messages){
        return;
    }
    const recivedMsgJson= JSON.parse(recivedMsg.Messages[0].Body)
    if (recivedMsgJson.type== "jobMappedInstituteRecived"){
        recivedMsgJson.instituteMapData.forEach(async element => {
            const jobRoleInstituteMap = new JobRoleInstituteMap();
            await jobRoleInstituteMap.create(element)
        });
        deleteMsgSQS(recivedMsg);
        return;
    }
}
receivedMsgFromSQS();