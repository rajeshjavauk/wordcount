module.exports = app => {
  const institutes = require("../controllers/institute.controller.js");

  var router = require("express").Router();

  // Retrive all institute campuses
  router.get("/institute-campus", institutes.findAll);

  app.use("/api/report", router);
};
