const client = require('./index')
//import client from './index'
//User constructor

function Institute() { }

// function Institute({
//     limit,
//     offset,
//     state
// }) {
//     this.limit = limit;
//     this.offset = offset;
//     this.state = state;
// };
// retreive all institue
Institute.prototype.findAll = async function () {
    try {
        await client.connect();
        const result = await client.query("select * from instituteslist");
        await client.end();
        return { result };
    } catch (error) {
        throw error;
    }
};

// retreive all institue
Institute.prototype.count = async function () {
    try {
        await client.connect();
        const result = await client.query("select count(1) from instituteslist");
        await client.end();
        return result;
    } catch (error) {
        throw error;
    }
};

// retreive all institue
Institute.prototype.page = async function (limit, offset, state) {
    try {
        await client.connect();
        const resultCount = await client.query("select count(1) as cnt from instituteslist");
        var count = 0;
        if (resultCount.rows != null) {
            count = resultCount.rows[0].cnt;
        }
        const result = await client.query("select * from instituteslist");
        await client.end();
        return { count, result };
    } catch (error) {
        throw error;
    }
};
module.exports = Institute;