module.exports = {
  HOST: "localhost",
  USER: "postgres",
  PORT: 5432,
  PASSWORD: "yahoo@123",
  DB: "institute",
  dialect: "postgres"
};