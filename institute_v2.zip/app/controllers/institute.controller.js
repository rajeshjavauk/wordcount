const Institute = require('../models/model.institute.js')

const getPagination = (page, size) => {
  const limit = size ? +size : 3;
  const offset = page ? page * limit : 0;
  return { limit, offset };
};

const getPagingData = (result, count, page, limit) => {
  const data = result.rows;
  const totalItems = count;
  const currentPage = page ? +page : 0;
  const totalPages = Math.ceil(totalItems / limit);
  return { totalItems, data, totalPages, currentPage };
};

// Retrieve all Tutorials from the database.
exports.findAll1 = async (req, res) => {
  try {
    const institute = new Institute();
    const { response } = await institute.findAll();
    res.status(200).send(response);
  } catch (e) {
    console.log(e.message);
  }
};

// Retrieve all Tutorials from the database.
exports.findAll = async (req, res) => {
  const { page, size, state } = req.query;
  const { limit, offset } = getPagination(page, size);
  try {
    const institute = new Institute();
    const { count, result } = await institute.page(limit, offset, state);
    const response = getPagingData(result, count, page, limit);
    res.status(200).send(response);
  } catch (e) {
    console.log(e.message);
  }
};