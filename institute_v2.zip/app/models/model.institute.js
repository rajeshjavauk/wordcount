const client = require('./index')

client.connect();
//import client from './index'
//User constructor

function Institute() { }

// function Institute({
//     limit,
//     offset,
//     state
// }) {
//     this.limit = limit;
//     this.offset = offset;
//     this.state = state;
// };
// retreive all institue
Institute.prototype.findAll = async function () {
    try {
        const result = await client.query("select * from instituteslist");
        return { result };
    } catch (error) {
        throw error;
    }
};

// retreive all institue
Institute.prototype.count = async function () {
    try {
        const result = await client.query("select count(1) from instituteslist");
        return result;
    } catch (error) {
        throw error;
    }
};

// retreive all institue
Institute.prototype.page = async function (limit, offset, state) {
    try {
        var condition = state ?` where state='${state}'`:'';
        const resultCount = await client.query(`select count(1) as cnt from instituteslist ${condition}`);
        var count = 0;
        if (resultCount.rows != null) {
            count = resultCount.rows[0].cnt;
        }
        const result = await client.query(`select * from instituteslist ${condition} limit ${limit} offset ${offset}`);
        return { count, result };
    } catch (error) {
        throw error;
    }
};
module.exports = Institute;