import React from 'react'
import { TableTop } from 'components/UIComponents/TableSearchFilter/Style/style'
import SearchInput from 'components/SearchInput'
import FilterDiv from 'components/FilterDiv'
import { FilterText } from 'components/FilterDiv'

const TableSearchFilter = ({
  menu,
  totalCount = 0,
  currentCount = 0,
  searchValue,
  setSearchValue,
  open,
  setOpen,
  placeholder = 'Search by keyword',
  onOpenChange,
}) => {
  return (
    <TableTop centerVertically>
      <SearchInput
        width={'20%'}
        placeholder={placeholder}
        bordered={false}
        searchValue={searchValue}
        setSearchValue={setSearchValue}
      />
      <FilterDiv
        overlayMenu={menu}
        open={open}
        setOpen={setOpen}
        onOpenChange={onOpenChange}
      />
      <FilterText>
        Showing {currentCount} 0f {totalCount}
      </FilterText>
    </TableTop>
  )
}

export default TableSearchFilter
