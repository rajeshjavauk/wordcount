import React from 'react'
import {
  StyledGroup,
  StyledCheckbox,
} from 'components/UIComponents/FilterCheckBoxComp/style'
import Flex from 'components/Flex'

const FilterCheckBoxComp = ({
  value,
  options,
  onChange,
  valueParam = 'value',
  labelParam = 'label',
}) => {
  return (
    <StyledGroup value={value} onChange={onChange}>
      {options?.map((item, index) => (
        <Flex spaceBetween centerVertically key={index}>
          <StyledCheckbox value={item[valueParam]} label={item[labelParam]} />
        </Flex>
      ))}
    </StyledGroup>
  )
}

export default FilterCheckBoxComp
