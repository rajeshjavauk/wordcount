import React, { Fragment } from 'react'
import styled from 'styled-components'
import { Select as AntdSelect } from 'antd'
import Label from 'components/Form/Label'
import Flex from 'components/Flex'
import SelectArrowIcon from 'components/icons/SelectArrowIcon'
import CrossIcon from 'components/icons/CrossIcon'
import { COLORS } from 'theme'
import SearchIcon from 'components/icons/SearchIcon'
import AntdAvatar from 'components/Avatar'
import {
  CollageNameFlex,
  CollegeNameDiv,
  CollegeCity,
  CollageDetailsFlex,
} from 'modules/Dashboard/Styles/style'

const { Option } = AntdSelect

const StyledSelect = styled(AntdSelect)`
  width: 100% !important;
  font-style: normal;
  font-weight: 400;
  font-size: 16px;
  line-height: 24px;
  color: #676e83;

  .ant-select-selector {
    background-color: ${props =>
      props?.disabled
        ? COLORS.DISABLED_SECONDARY
        : props.backgroundcolor
        ? props.backgroundcolor
        : '#ffffff'} !important;
    border-radius: 8px !important;
    border-color: #e9e9e9 !important;
    box-shadow: none !important;
  }
  .ant-select-selection-item {
    background-color: ${props =>
      props?.mode === 'multiple' ? '#ebecee' : 'transparent'};
    color: ${COLORS.GREY_P_100};
  }
  :hover {
    background-color: transparent;
  }
  .ant-select-dropdown-placement-bottomLeft {
    width: 1000px !important;
  }
  .ant-select-selection-item-remove {
    display: flex;
    align-items: center;
  }
`
const LabelWrapper = styled.div`
  padding-bottom: 8px;
  line-height: 12px;
`
const IconSpan = styled.span`
  margin-left: 8px;
`

const Select = ({
  OptionData,
  placeholder,
  labelStyle,
  onChange,
  label,
  value,
  position = 'relative',
  width = '100%',
  defaultValue,
  loading,
  bordered = true,
  valueParam = 'id',
  nameParam = 'name',
  lastNameParam,
  showSearch = false,
  backgroundcolor,
  icon,
  disabled,
  isSearchSelect,
  ...rest
}) => {
  return (
    <Flex
      column
      style={{
        width: width,
        position: position,
      }}
      id="select"
    >
      {label && (
        <LabelWrapper>
          <Label labelStyle={labelStyle}>{label}</Label>
        </LabelWrapper>
      )}

      <StyledSelect
        showSearch={showSearch}
        suffixIcon={isSearchSelect ? <SearchIcon /> : <SelectArrowIcon />}
        placeholder={placeholder}
        onChange={onChange}
        size={'large'}
        value={value || undefined}
        loading={loading}
        bordered={bordered}
        defaultValue={defaultValue}
        backgroundcolor={backgroundcolor}
        removeIcon={<CrossIcon />}
        disabled={disabled}
        getPopupContainer={() => document.getElementById('select')}
        {...rest}
      >
        {OptionData?.map((option, index) => {
          return (
            <Option
              style={{
                padding: isSearchSelect ? '0px 12px' : '10px 12px',
              }}
              key={option[valueParam]}
              value={option[valueParam]}
              id={option?.id}
              name={option[nameParam]}
              option={option}
              label={
                isSearchSelect
                  ? `${option[nameParam]} ${option[lastNameParam]}`
                  : option[nameParam]
              }
            >
              {!isSearchSelect ? (
                <Fragment>
                  {option[nameParam]}
                  {icon ? <IconSpan>{icon}</IconSpan> : null}
                </Fragment>
              ) : (
                <CollageDetailsFlex
                  spaceBetween
                  centerVertically
                  isBoarder={OptionData?.length - 1 === index}
                >
                  <Flex alignCenter>
                    <AntdAvatar
                      size={36}
                      IconName={option?.first_name?.charAt()?.toUpperCase()}
                    />
                    <CollageNameFlex>
                      <CollegeNameDiv>
                        {option?.first_name} {option?.last_name}
                      </CollegeNameDiv>
                      <CollegeCity>{option?.email}</CollegeCity>
                    </CollageNameFlex>
                  </Flex>
                </CollageDetailsFlex>
              )}
            </Option>
          )
        })}
      </StyledSelect>
    </Flex>
  )
}

export default Select
