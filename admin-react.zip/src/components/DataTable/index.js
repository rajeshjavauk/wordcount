import React, { useState } from 'react'
import { StyledTable } from 'components/TableStyles/TableStyles'
import { RowNumberData, Wrapper } from 'components/TableStyles/TableContentStyles/TableContentStyles'
import Pagination from 'components/Pagination'
import { EmptyWrapper } from 'modules/Dashboard/Styles/style'
import { Empty, Spin } from 'antd'

const DataTable = ({
  dataSet,
  columns,
  setPage,
  page,
  setSortBy,
  loading,
}) => {
  const onSorting = (pagination, filter, sorter) => {
    setSortBy(sorter)
  }

  const onPageChange = num => {
    setPage(num - 1)
  }

  return (
    <>
      <Wrapper>
        <StyledTable
          columns={columns}
          pagination={false}
          dataSource={dataSet?.result}
          onChange={onSorting}
          locale={{
            emptyText: (
              <EmptyWrapper center isSpin={loading}>
                {!loading ? <Empty description={'No data found!'} /> : <Spin />}
              </EmptyWrapper>
            ),
          }}
        />

        <Pagination
          onChange={onPageChange}
          totalPages={dataSet?.totalPage}
          pageSize={1}
          current={page + 1}
        />
      </Wrapper>
    </>
  )
}

export default DataTable