import PageNotFound from 'routes/Components/PageNotFound'
import Dashboard from 'modules/Dashboard/Container/index'
import CorporateEmpanelled from 'modules/CorporateEmpanelled/Container/index'
import Corporates from 'modules/Corporates/Container/index'
import Institutes from 'modules/Institutes/Container/index'
import InstituteEmpanelled from 'modules/InstituteEmpanelled/Container/index'
import Top10Corporates from 'modules/Top10Corporates/Container/index'
import Top10Institutes from 'modules/Top10Institutes/Container/index'

export const authenticated = [
  {
    routePath: '/dashboard',
    Component: Dashboard,
  },
  {
    routePath: '/corporates',
    Component: Corporates,
  },
  {
    routePath: '/institutes',
    Component: Institutes,
  },
  {
    routePath: '/corporate-empanelled',
    Component: CorporateEmpanelled,
  },
  {
    routePath: '/institute-empanelled',
    Component: InstituteEmpanelled,
  },
  {
    routePath: '/top10-corporates',
    Component: Top10Corporates,
  },
  {
    routePath: '/top10-institutes',
    Component: Top10Institutes,
  },
  {
    routePath: '*',
    Component: PageNotFound,
  },
]
