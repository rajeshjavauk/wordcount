import React, { useEffect } from 'react'
import { Route, Routes, useNavigate, useSearchParams } from 'react-router-dom'
import Page from 'modules/Page/Container/index'
import { authenticated } from 'routes/config/user'
import Flex from 'components/Flex'
import styled from 'styled-components'
import { useDispatch } from 'react-redux'
import { SignIn } from 'modules/Auth/actions'

const { AUTH_URL } = process.env

const PageFlex = styled(Flex)`
  overflow: hidden;
`
const AuthPage = ({ isAuthenticated }) => {
  const navigate = useNavigate()
  const dispatch = new useDispatch()
  const [searchParams] = useSearchParams()

  useEffect(() => {
    const authToken = searchParams.get('token')
    dispatch(SignIn(authToken))
    if (!authToken && !isAuthenticated) {
      window.open(AUTH_URL, '_self')
    }
  }, [])

  useEffect(() => {
    if (isAuthenticated) {
      navigate('/corporates')
    }
  }, [isAuthenticated])

  return (
    <PageFlex>
      {isAuthenticated && (
        <>
          <Page>
            <Routes>
              {authenticated.map(({ routePath, Component }) => {
                return (
                  <Route
                    key={routePath}
                    path={routePath}
                    element={<Component />}
                  ></Route>
                )
              })}
            </Routes>
          </Page>
        </>
      )}
    </PageFlex>
  )
}

export default AuthPage
