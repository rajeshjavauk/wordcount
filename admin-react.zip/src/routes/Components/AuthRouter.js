import React, { Fragment } from 'react'
import AuthPage from 'routes/Components/AuthPage'

const AuthRouter = ({ isAuthenticated }) => {
  return (
    <Fragment>
      <AuthPage isAuthenticated={isAuthenticated} />
    </Fragment>
  )
}

export default AuthRouter
