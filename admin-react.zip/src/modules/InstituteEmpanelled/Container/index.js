import { connect } from 'react-redux'
import InstituteEmpanelled from 'modules/InstituteEmpanelled/index'
import selector from 'modules/InstituteEmpanelled/selectors'
import { getRoleList } from 'modules/InstituteEmpanelled/actions'
const mapStateToProps = state => ({
  roleList: selector.getRoleLists(state),
})

const mapDispatchToProps = {
  getRoleList,
}

export default connect(mapStateToProps, mapDispatchToProps)(InstituteEmpanelled)
