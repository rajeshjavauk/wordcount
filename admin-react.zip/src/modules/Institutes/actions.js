import axios from 'axios'

export const setRoleList = data => {
  return {
    type: 'SET_ROLE_LIST',
    data,
  }
}
export const getRoleList =
  ({ page }) =>
    async (dispatch, getState) => {
      try {
        console.log(
          `http://localhost:9006/corporates-report/lists?page=${page}&size=1`
        )
        /*
        const res = await axios.get(
          `http://localhost:9006/corporates-report/lists?page=${page}&size=1`
        )
        */
        let res;
        res = {
          "message": "Success",
          "data": {
            "result": [
              {
                "name": "CTS",
                "tier": "CTS",
                "created_at": "CTS",
                "state": "CTS",
                "city": "CTS",
                "contact_person": "CTS",
                "contact_number": "CTS",
              },
              {
                "name": "TCS",
                "tier": "TCS",
                "created_at": "TCS",
                "state": "TCS",
                "city": "TCS",
                "contact_person": "TCS",
                "contact_number": "TCS",
              },
              {
                "name": "Infosys",
                "tier": "Infosys",
                "created_at": "Infosys",
                "state": "Infosys",
                "city": "Infosys",
                "contact_person": "Infosys",
                "contact_number": "Infosys",
              }
            ],
            "count": 3,
            "page": 0,
            "limit": 10,
            "totalPage": 1
          },
          "error": {}
        }
        console.log(res.data)
        dispatch(setRoleList(res.data))
        console.log(getState())
        console.log('role list data fetched successfully')
      } catch (error) {
        console.log('Error in Getting Jobs list', error)
      }
    }
