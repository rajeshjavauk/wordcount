import React, { useState } from 'react'
import {
  BrowserRouter as Router,
  Switch,
  Link,
  Route,
  Redirect,
} from 'react-router-dom'
import {
  SectionWrapper,
  PageTitle,
  HeadTitle,
} from 'modules/Institutes/Styles/style'
import { useEffect } from 'react'
import DataTable from 'components/DataTable'

const Institutes = ({ getRoleList, roleList }) => {
  const columns = [
    {
      title: 'name',
      dataIndex: 'name',
      key: 'name',
      sorter: true,
      render: rowData => rowData,
    },
    {
      title: 'tier',
      dataIndex: 'tier',
      key: 'tier',
      sorter: true,
      render: rowData => rowData,
    },
    {
      title: 'created at',
      dataIndex: 'created_at',
      key: 'created_at',
      sorter: true,
      render: rowData => rowData,
    },
    {
      title: 'state',
      dataIndex: 'state',
      key: 'state',
      sorter: true,
      render: rowData => rowData,
    },{
      title: 'city',
      dataIndex: 'city',
      key: 'city',
      sorter: true,
      render: rowData => rowData,
    },
    {
      title: 'contact person',
      dataIndex: 'contact_person',
      key: 'contact_person',
      sorter: true,
      render: rowData => rowData,
    },
    ,
    {
      title: 'contact number',
      dataIndex: 'contact_number',
      key: 'contact_number',
      sorter: true,
      render: rowData => rowData,
    },
  ]
  const [page, setPage] = useState(0)
  useEffect(() => {
    getRoleList({ page })
  }, [page]);

  return (
    <>
      <SectionWrapper column>
        <PageTitle>
          <HeadTitle>Institutes</HeadTitle>
        </PageTitle>
        {/* <UsersFilter roleList={roleList} /> */}
        <DataTable columns={columns} dataSet={roleList} page={page} setPage={setPage} />
      </SectionWrapper>
    </>
  )
}

export default Institutes
