import { connect } from 'react-redux'
import Institutes from 'modules/Institutes/index'
import selector from 'modules/Institutes/selectors'
import { getRoleList } from 'modules/Institutes/actions'
const mapStateToProps = state => ({
  roleList: selector.getRoleLists(state),
})

const mapDispatchToProps = {
  getRoleList,
}

export default connect(mapStateToProps, mapDispatchToProps)(Institutes)
