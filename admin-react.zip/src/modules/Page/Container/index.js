import { connect } from 'react-redux'

import Page from 'modules/Page/Components/index'

const mapStateToProps = () => ({})

const mapDispatchToProps = {}

export default connect(mapStateToProps, mapDispatchToProps)(Page)
