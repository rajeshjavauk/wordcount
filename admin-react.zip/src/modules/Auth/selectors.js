const getToken = state => state?.auth?.token
const selectors = {
  getToken,
}

export default selectors
