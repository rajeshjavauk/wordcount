/* eslint-disable no-unused-vars */
import initializeApp from 'utils/initializeApp'
import jwtDecode from 'jwt-decode'

export const SIGN_IN_SUCCESS = 'SIGN_IN_SUCCESS'
export const SET_STUDENT_ID = 'SET_STUDENT_ID'

export const SignInSuccess = token => {
  return {
    type: SIGN_IN_SUCCESS,
    token,
  }
}

export const SignIn = token => async dispatch => {
  try {
    if (token) {
      // const decodedToken = jwtDecode(token)
      initializeApp(token)
      dispatch(SignInSuccess(token))
    }
  } catch (error) {
    console.error('Getting error while login', error)
  }
}
