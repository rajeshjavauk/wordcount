import React from 'react'
import TotalUsers from 'components/icons/TotalUsers'
import ActiveUsers from 'components/icons/ActiveUsers'
import InactiveUsers from 'components/icons/InactiveUsers'
import MailInvite from 'components/icons/MailInvite'

export const getCardData = userMetrics => {
  return [
    {
      key: 1,
      icon: <TotalUsers />,
      text: 'Total Users',
      value: userMetrics?.totalUsers || 0,
      state: 'all',
      current: 'Total Users',
    },
    {
      key: 2,
      icon: <ActiveUsers />,
      text: 'Active',
      value: userMetrics?.activeUsers || 0,
      state: 'true',
      current: 'Active',
    },
    {
      key: 3,
      icon: <InactiveUsers />,
      text: 'Inactive',
      value: userMetrics?.inActiveUsers || 0,
      state: 'false',
      current: 'Inactive',
    },
  ]
}
