import React, { useState } from 'react'
import TableSearchFilter from 'components/UIComponents/TableSearchFilter'
import {
  StyledTab,
  SubmitFlex,
  MenuFlex,
} from 'modules/Dashboard/Partials/UsersFilter/Styles/style'
import Button from 'components/Button/index'
import UserRoleFilter from 'modules/Dashboard/Partials/UsersFilter/Partials/UserRoleFilter'
import StatusFilter from 'modules/Dashboard/Partials/UsersFilter/Partials/StatusFilter'
import CheckIconWhite from 'components/icons/CheckIconWhite'

const UsersFilter = ({
  searchValue,
  setSearchValue,
  userRole,
  userRoleValue,
  setUserRoleValue,
  userStatus,
  setUserStatus,
  getUserData,
  setState,
  userList,
  roleList,
}) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [filterData, setFilterData] = useState({})

  const submitFilter = () => {
    setIsMenuOpen(false)
    setFilterData({
      role: userRoleValue,
      status: userStatus,
    })
    getUserData()
    setState(userStatus ? userStatus : 'all')
  }

  const onCancelFilter = open => {
    setIsMenuOpen(!isMenuOpen)
    setUserRoleValue(filterData?.role)
    setUserStatus(filterData?.status)
  }

  const menu = (
    <MenuFlex column className="filter">
      <StyledTab
        border={true}
        tabPosition={'left'}
        type="card"
        padding="15px"
        popupClassName="filter"
        items={[
          {
            label: 'Industry',
            key: '1',
            children: (
              <UserRoleFilter
                userRole={userRole}
                userRoleValue={userRoleValue}
                setUserRoleValue={setUserRoleValue}
              />
            ),
          },
          {
            label: 'City',
            key: '2',
            children: (
              <StatusFilter
                userStatus={userStatus}
                setUserStatus={setUserStatus}
              />
            ),
          },
        ]}
      />
      <SubmitFlex right>
        <Button.Secondary text="Cancel" onClick={() => onCancelFilter(false)} />
        <Button.Primary
          onClick={submitFilter}
          text="Save Changes"
          icon={<CheckIconWhite />}
        />
      </SubmitFlex>
    </MenuFlex>
  )

  return (
    <TableSearchFilter
      menu={menu}
      open={isMenuOpen}
      setOpen={setIsMenuOpen}
      searchValue={searchValue}
      setSearchValue={setSearchValue}
      currentCount={
        roleList?.count < 10
          ? roleList.count
          : roleList.currentPage * 10 - 10 + roleList.list?.length
      }
      totalCount={roleList?.count}
      onOpenChange={onCancelFilter}
    />
  )
}

export default UsersFilter
