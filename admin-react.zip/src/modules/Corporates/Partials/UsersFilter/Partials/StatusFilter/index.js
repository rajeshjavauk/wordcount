import React from 'react'
import FilterCheckBoxComp from 'components/UIComponents/FilterCheckBoxComp'
import { Wrapper } from 'modules/Dashboard/Partials/UsersFilter/Styles/style'

const StatusFilter = ({ userStatus, setUserStatus }) => {
  const options1 = [
    {
      label: 'Active',
      value: 'true',
    },
    {
      label: 'Inactive',
      value: 'false',
    },
  ]

  return (
    <Wrapper column>
      <FilterCheckBoxComp
        value={userStatus}
        options={options1}
        onChange={value => setUserStatus([value[value?.length - 1]])}
      />
    </Wrapper>
  )
}

export default StatusFilter
