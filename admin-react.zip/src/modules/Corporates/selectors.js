const getRoleLists = state => state?.roleListData?.roleList

const selector = {
  getRoleLists,
}

export default selector
