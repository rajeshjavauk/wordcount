const initialState = {
  roleList: {},
}

export default (state = initialState, action) => {
  switch (action.type) {
    case 'SET_ROLE_LIST':
      return {
        ...state,
        roleList: action.data,
      }

    default:
      return state
  }
}
