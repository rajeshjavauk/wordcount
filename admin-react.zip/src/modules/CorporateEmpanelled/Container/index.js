import { connect } from 'react-redux'
import CorporateEmpanelled from 'modules/CorporateEmpanelled/index'
import selector from 'modules/CorporateEmpanelled/selectors'
import { getRoleList } from 'modules/CorporateEmpanelled/actions'
const mapStateToProps = state => ({
  roleList: selector.getRoleLists(state),
})

const mapDispatchToProps = {
  getRoleList,
}

export default connect(mapStateToProps, mapDispatchToProps)(CorporateEmpanelled)
