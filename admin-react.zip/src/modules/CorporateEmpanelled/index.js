import React, { useState } from 'react'
import {
  BrowserRouter as Router,
  Switch,
  Link,
  Route,
  Redirect,
} from 'react-router-dom'
import {
  SectionWrapper,
  PageTitle,
  HeadTitle,
} from 'modules/CorporateEmpanelled/Styles/style'
import { useEffect } from 'react'
import DataTable from 'components/DataTable'

const CorporateEmpanelled = ({ getRoleList, roleList }) => {
  const columns = [
    {
      title: 'name',
      dataIndex: 'name',
      key: 'name',
      sorter: true,
      render: rowData => rowData,
    },
    {
      title: 'contact email',
      dataIndex: 'contact_email',
      key: 'contact_email',
      sorter: false,
      render: rowData => rowData,
    },
    {
      title: 'Date onboarded',
      dataIndex: 'created_at',
      key: 'created_at',
      sorter: false,
      render: rowData => rowData,
    },
    {
      title: 'industry',
      dataIndex: 'industry',
      key: 'industry',
      sorter: false,
      render: rowData => rowData,
    },
    {
      title: 'state',
      dataIndex: 'state',
      key: 'state',
      sorter: false,
      render: rowData => rowData,
    },
    {
      title: 'city',
      dataIndex: 'city',
      key: 'city',
      sorter: false,
      render: rowData => rowData,
    },
    {
      title: 'contact number',
      dataIndex: 'contact_number',
      key: 'contact_number',
      sorter: false,
      render: rowData => rowData,
    },
  ]
  const [page, setPage] = useState(0)
  useEffect(() => {
    getRoleList({ page })
  }, [page]);

  return (
    <>
      <SectionWrapper column>
        <PageTitle><HeadTitle>Corporate Empanelled</HeadTitle></PageTitle>
        {/* <UsersFilter roleList={roleList} /> */}
        <DataTable columns={columns} dataSet={roleList} page={page} setPage={setPage} />
      </SectionWrapper>
    </>
  )
}

export default CorporateEmpanelled
