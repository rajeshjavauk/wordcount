import { connect } from 'react-redux'
import Dashboard from 'modules/Dashboard/index'
import selector from 'modules/Dashboard/selectors'
import { getRoleList } from 'modules/Dashboard/actions'
const mapStateToProps = state => ({
  roleList: selector.getRoleLists(state),
})

const mapDispatchToProps = {
  getRoleList,
}

export default connect(mapStateToProps, mapDispatchToProps)(Dashboard)
