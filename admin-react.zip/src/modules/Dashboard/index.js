import React, { useState } from 'react'
import {
  BrowserRouter as Router,
  Switch,
  Link,
  Route,
  Redirect,
} from 'react-router-dom'
import {
  SectionWrapper,
  PageTitle,
  HeadTitle,
} from 'modules/Dashboard/Styles/style'
import { useEffect } from 'react'
import DataTable from 'components/DataTable'

const Dashboard = ({ getRoleList, roleList }) => {
  const columns = [
    {
      title: 'name',
      dataIndex: 'name',
      key: 'name',
      sorter: true,
      render: rowData => rowData,
    },
  ]
  const [page, setPage] = useState(0)
  useEffect(() => {
    getRoleList({ page })
  }, [page]);

  return (
    <>
      <SectionWrapper column>
        <PageTitle>
          <HeadTitle>Dashboard</HeadTitle>
        </PageTitle>
        {/* <UsersFilter roleList={roleList} /> */}
        <DataTable columns={columns} dataSet={roleList} page={page} setPage={setPage} />
      </SectionWrapper>
    </>
  )
}

export default Dashboard
