import { connect } from 'react-redux'
import Top10Corporates from 'modules/Top10Corporates/index'
import selector from 'modules/Top10Corporates/selectors'
import { getRoleList } from 'modules/Top10Corporates/actions'
const mapStateToProps = state => ({
  roleList: selector.getRoleLists(state),
})

const mapDispatchToProps = {
  getRoleList,
}

export default connect(mapStateToProps, mapDispatchToProps)(Top10Corporates)
