import { connect } from 'react-redux'
import Top10Institutes from 'modules/Top10Institutes/index'
import selector from 'modules/Top10Institutes/selectors'
import { getRoleList } from 'modules/Top10Institutes/actions'
const mapStateToProps = state => ({
  roleList: selector.getRoleLists(state),
})

const mapDispatchToProps = {
  getRoleList,
}

export default connect(mapStateToProps, mapDispatchToProps)(Top10Institutes)
