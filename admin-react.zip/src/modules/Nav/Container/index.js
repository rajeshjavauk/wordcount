import { connect } from 'react-redux'

import Nav from 'modules/Nav/index'

const mapStateToProps = () => ({})

const mapDispatchToProps = {}

export default connect(mapStateToProps, mapDispatchToProps)(Nav)
