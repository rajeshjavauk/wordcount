import React from 'react'

const Systems = ({ color = '#999FAC' }) => (
<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 18 18" fill="none">
<path d="M10 6V4H13V0H15V4H18V6H10ZM13 18V8H15V18H13ZM3 18V14H0V12H8V14H5V18H3ZM3 10V0H5V10H3Z" fill="#B3B7C1"/>
</svg>
)

export default Systems
