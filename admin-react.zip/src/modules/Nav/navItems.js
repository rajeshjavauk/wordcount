import DasgboardIcon from 'modules/Nav/icons/DasgboardIcon'
import OnboardingIcon from 'modules/Nav/icons/OnboardingIcon'
import CorporateIcon from 'modules/Nav/icons/CorporateIcon'
import InstituteIcon from 'modules/Nav/icons/InstituteIcon'
import ExStudents from 'modules/Nav/icons/Exstudents'
import Payments from 'modules/Nav/icons/Payments'
import Users from 'modules/Nav/icons/Users'
import Systems from 'modules/Nav/icons/Systems'
import SettingIcon from 'modules/Nav/icons/SettingIcon'

export const navItems = [
  {
    path: '/corporates',
    icon: CorporateIcon,
    navTitle: 'Corporates',
    pageTitle: 'Corporates',
    menuType: 'GlobalMenu',
  },
  {
    path: '/institutes',
    icon: InstituteIcon,
    navTitle: 'Institutes',
    pageTitle: 'Institutes',
    menuType: 'GlobalMenu',
  },
  {
    path: '/corporate-empanelled',
    icon: CorporateIcon,
    navTitle: 'Empanelled Corp..',
    pageTitle: 'Empanelled Corp..',
    menuType: 'GlobalMenu',
  },
  {
    path: '/institute-empanelled',
    icon: InstituteIcon,
    navTitle: 'Empanelled Insti..',
    pageTitle: 'Empanelled Insti..',
    menuType: 'GlobalMenu',
  },
  {
    path: '/top10-corporates',
    icon: CorporateIcon,
    navTitle: 'Top 10 Corporates',
    pageTitle: 'Top 10 Corporates',
    menuType: 'GlobalMenu',
  },
  {
    path: '/top10-institutes',
    icon: InstituteIcon,
    navTitle: 'Top 10 Institutes',
    pageTitle: 'Top 10 Institutes',
    menuType: 'GlobalMenu',
  }
]
