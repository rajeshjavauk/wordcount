import { combineReducers } from 'redux'
import authReducer from 'modules/Auth/reducers'
import RoleList from 'modules/Dashboard/reducers'

export default combineReducers({
  auth: authReducer,
  roleListData: RoleList,
})
