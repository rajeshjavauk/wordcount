import { createGlobalStyle } from 'styled-components'

const GlobalStyle = createGlobalStyle`
  body {
    margin: 0;
    padding: 0;
    background: #FAFAFB;
    font-family: Inter, sans-serif;
    style:normal;
    weight:400;
    size:11px;
    line-height:16px
  }
`

export default GlobalStyle
