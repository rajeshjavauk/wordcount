import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { render } from 'react-dom';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component

import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS

const App = () => {

  const [state, setState] = useState("");
  const [city, setCity] = useState("");
  const [createdAtStart, setCreatedAtStart] = useState("");
  const [createdAtEnd, setCreatedAtEnd] = useState("");
  const [page, setPage] = useState("");
  const [size, setSize] = useState("");

  const gridRef = useRef(); // Optional - for accessing Grid's API
  const [rowData, setRowData] = useState(); // Set rowData to Array of Objects, one Object per Row

  // Each Column Definition results in one Column.
  const [columnDefs, setColumnDefs] = useState([
    { field: 'id', filter: true },
    { field: 'state', filter: true },
    { field: 'city', filter: true },
    { field: 'createdAt', filter: true },
    { field: 'name' },
    { field: 'logo' },
    { field: 'industry' },
    { field: 'addressLine1' },
    { field: 'addressLine2' },
    { field: 'cityId' },
    { field: 'stateId' },
    { field: 'country' },
    { field: 'countryId' },
    { field: 'postalCode' },
    { field: 'website' },
    { field: 'contactNumber' },
    { field: 'contactEmail' },
    { field: 'corporateType' },
    { field: 'pan' },
    { field: 'isActive' },
    { field: 'updateAt' },
    { field: 'deletedAt' }
  ]);

  let handleSubmit = async (e) => {
    e.preventDefault();
    try {
      let queryString = "?";
      if (state) {
        queryString = queryString + "state=" + state + "&";
      }
      if (city) {
        queryString = queryString + "city=" + city + "&";
      }
      if (createdAtStart) {
        queryString = queryString + "createdAtStart=" + createdAtStart + "&";
      }
      if (createdAtEnd) {
        queryString = queryString + "createdAtEnd=" + createdAtEnd + "&";
      }
      if (page) {
        queryString = queryString + "page=" + page + "&";
      }
      if (size) {
        queryString = queryString + "size=" + size + "&";
      }
      console.log(queryString);

      let res = await fetch('http://localhost:9006/corporates-report/lists' + queryString)
        .then(result => result.json())
        .then(rowData => setRowData(rowData.data.result));
    } catch (err) {
      console.log(err);
    }
  };

  // DefaultColDef sets props common to all Columns
  const defaultColDef = useMemo(() => ({
    sortable: true
  }));

  // Example of consuming Grid Event
  const cellClickedListener = useCallback(event => {
    console.log('cellClicked', event);
  }, []);

  // Example load data from sever
  useEffect(() => {
    fetch('http://localhost:9006/corporates-report/lists')
      .then(result => result.json())
      .then(rowData => setRowData(rowData.data.result))
  }, []);

  // Example using Grid's API
  const buttonListener = useCallback(e => {
    gridRef.current.api.deselectAll();
  }, []);

  return (
    <div>


      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={state}
          placeholder="State"
          onChange={(e) => setState(e.target.value)}
        />
        <input
          type="text"
          value={city}
          placeholder="City"
          onChange={(e) => setCity(e.target.value)}
        />
        <input
          type="text"
          value={createdAtStart}
          placeholder="Created At Start"
          onChange={(e) => setCreatedAtStart(e.target.value)}
        />
        <input
          type="text"
          value={createdAtEnd}
          placeholder="Created At End"
          onChange={(e) => setCreatedAtEnd(e.target.value)}
        />
        <input
          type="text"
          value={page}
          placeholder="Page"
          onChange={(e) => setPage(e.target.value)}
        />
        <input
          type="text"
          value={size}
          placeholder="Size"
          onChange={(e) => setSize(e.target.value)}
        />

        <button type="submit">Search</button>
      </form>


      {/* Example using Grid's API */}
      
      {/* On div wrapping Grid a) specify theme CSS Class Class and b) sets Grid size */}
      <div className="ag-theme-alpine" style={{ height: 2500 }}>

        <AgGridReact
          ref={gridRef} // Ref for accessing Grid's API

          rowData={rowData} // Row Data for Rows

          columnDefs={columnDefs} // Column Defs for Columns
          defaultColDef={defaultColDef} // Default Column Properties

          animateRows={true} // Optional - set to 'true' to have rows animate when sorted
          rowSelection='multiple' // Options - allows click selection of rows

          onCellClicked={cellClickedListener} // Optional - registering for Grid Event
        />
      </div>
    </div>
  );
};

export default App;